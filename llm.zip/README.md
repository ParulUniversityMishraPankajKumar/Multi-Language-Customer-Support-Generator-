# AI-Powered Order Management & Customer Support System

एक comprehensive AI system जो order cancellation को analyze करके future predictions देता है और multi-language customer support भी provide करता है।

## 🎯 Core Features

### Order Cancellation Analysis System
- **Order Details Extraction**: Cancelled order की complete information capture करता है
- **Cancellation Reason Analysis**: AI के through cancellation का exact reason identify करता है  
- **Problem Identification**: Root cause analysis करके main problem explain करता है
- **Future Prediction**: Machine learning से predict करता है कि future में order cancel होगा या नहीं
- **Customer Behavior Analysis**: Customer के past behavior को analyze करता है
- **Actionable Recommendations**: Concrete steps suggest करता है problem solve करने के लिए

### Multi-Language Customer Support
- **Multi-language Detection**: Automatically detects the language of incoming queries
- **Translation Service**: Translates queries and responses
- **AI Response Generation**: Contextually appropriate responses
- **Support Ticket Management**: Complete ticket lifecycle management
- **Analytics Dashboard**: Comprehensive metrics and insights

## Supported Languages

- English (en)
- Spanish (es)
- French (fr)
- German (de)
- Italian (it)
- Portuguese (pt)
- Chinese (zh)
- Japanese (ja)
- Korean (ko)
- Arabic (ar)

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file with your API keys:
   ```
   OPENAI_API_KEY=your_openai_api_key
   PORT=3000
   ```
4. Start the application:
   ```bash
   npm start
   ```

## API Endpoints

- `POST /api/support/query` - Submit a customer support query
- `GET /api/support/ticket/:id` - Get ticket details
- `GET /api/support/analytics` - Get support analytics
- `GET /api/languages` - Get supported languages

## Usage

### Submit a Support Query

```javascript
const response = await fetch('/api/support/query', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: "¿Cómo puedo restablecer mi contraseña?",
    customerEmail: "customer@example.com"
  })
});
```

## Architecture

- **Language Detection**: Uses language detection algorithms to identify input language
- **Translation**: Google Translate API for language translation
- **AI Processing**: OpenAI GPT for response generation
- **Response Management**: Structured response system with templates

## Testing

```bash
npm test
```

## Development

```bash
npm run dev
```
