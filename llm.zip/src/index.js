const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { v4: uuidv4 } = require('uuid');
const SupportService = require('./services/SupportService');
const TranslationService = require('./services/TranslationService');
const LanguageDetector = require('./services/LanguageDetector');
const ResponseGenerator = require('./services/ResponseGenerator');
const logger = require('./utils/logger');
const orderRoutes = require('./routes/orders');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Initialize services
const translationService = new TranslationService();
const languageDetector = new LanguageDetector();
const responseGenerator = new ResponseGenerator();
const supportService = new SupportService({
  translationService,
  languageDetector,
  responseGenerator
});

// Routes
app.get('/', (req, res) => {
  res.json({
    message: 'AI-Powered Order Management & Customer Support System',
    version: '2.0.0',
    features: [
      'Multi-language customer support',
      'Order cancellation analysis',
      'Future cancellation prediction',
      'Customer behavior insights',
      'Real-time analytics'
    ],
    endpoints: {
      // Customer Support Endpoints
      'POST /api/support/query': 'Submit a customer support query',
      'GET /api/support/ticket/:id': 'Get ticket details',
      'GET /api/support/analytics': 'Get support analytics',
      'GET /api/languages': 'Get supported languages',
      
      // Order Management Endpoints
      'POST /api/orders': 'Create a new order',
      'GET /api/orders/:orderId': 'Get order details',
      'POST /api/orders/:orderId/cancel': 'Cancel order with AI analysis',
      'GET /api/orders/:orderId/analysis': 'Get detailed order analysis',
      'GET /api/customers/:customerId/orders': 'Get customer order history',
      'GET /api/analytics/cancellations': 'Get cancellation analytics',
      
      // Demo Endpoints
      'POST /api/demo/sample-orders': 'Generate sample orders for testing',
      'POST /api/demo/cancel-sample/:orderId': 'Cancel sample order with analysis'
    }
  });
});

// Use order routes
app.use('/api', orderRoutes);

// Submit customer support query
app.post('/api/support/query', async (req, res) => {
  try {
    const { message, customerEmail, customerName } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    logger.info('Processing support query', { 
      customerEmail, 
      messageLength: message.length 
    });

    const ticket = await supportService.processQuery({
      id: uuidv4(),
      message,
      customerEmail: customerEmail || 'anonymous@example.com',
      customerName: customerName || 'Anonymous Customer',
      timestamp: new Date().toISOString()
    });

    res.json(ticket);
  } catch (error) {
    logger.error('Error processing support query:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      message: 'Failed to process your query. Please try again.'
    });
  }
});

// Get ticket details
app.get('/api/support/ticket/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const ticket = await supportService.getTicket(id);
    
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json(ticket);
  } catch (error) {
    logger.error('Error fetching ticket:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get support analytics
app.get('/api/support/analytics', async (req, res) => {
  try {
    const analytics = await supportService.getAnalytics();
    res.json(analytics);
  } catch (error) {
    logger.error('Error fetching analytics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get supported languages
app.get('/api/languages', (req, res) => {
  const supportedLanguages = languageDetector.getSupportedLanguages();
  res.json(supportedLanguages);
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: 'Something went wrong. Please try again.'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, () => {
  logger.info(`AI-Powered Order Management & Customer Support System running on port ${PORT}`);
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📚 API Documentation available at http://localhost:${PORT}`);
  console.log(`🔍 Order Cancellation Analysis System Ready`);
  console.log(`🤖 AI-Powered Prediction Engine Active`);
});

module.exports = app;
