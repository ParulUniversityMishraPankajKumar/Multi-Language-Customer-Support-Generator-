const express = require('express');
const OrderManagementService = require('../services/OrderManagementService');
const logger = require('../utils/logger');

const router = express.Router();
const orderService = new OrderManagementService();

/**
 * POST /api/orders - Create a new order
 */
router.post('/orders', async (req, res) => {
  try {
    const order = await orderService.createOrder(req.body);
    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: order.toJSON()
    });
  } catch (error) {
    logger.error(`Error creating order: ${error.message}`);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * GET /api/orders/:orderId - Get order details
 */
router.get('/orders/:orderId', async (req, res) => {
  try {
    const order = orderService.getOrder(req.params.orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.json({
      success: true,
      data: order.toJSON()
    });
  } catch (error) {
    logger.error(`Error fetching order: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * POST /api/orders/:orderId/cancel - Cancel order with analysis
 * Body: { reason: string, additionalDetails?: object }
 */
router.post('/orders/:orderId/cancel', async (req, res) => {
  try {
    const { reason, additionalDetails = {} } = req.body;
    
    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Cancellation reason is required'
      });
    }

    const result = await orderService.cancelOrderWithAnalysis(
      req.params.orderId, 
      reason, 
      additionalDetails
    );

    res.json({
      success: true,
      message: 'Order cancelled and analyzed successfully',
      data: result
    });

  } catch (error) {
    logger.error(`Error cancelling order: ${error.message}`);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * GET /api/orders/:orderId/analysis - Get detailed order analysis
 */
router.get('/orders/:orderId/analysis', async (req, res) => {
  try {
    const analysis = await orderService.getOrderAnalysis(req.params.orderId);
    
    res.json({
      success: true,
      data: analysis
    });

  } catch (error) {
    logger.error(`Error getting order analysis: ${error.message}`);
    res.status(404).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * GET /api/customers/:customerId/orders - Get customer order history
 */
router.get('/customers/:customerId/orders', async (req, res) => {
  try {
    const orders = orderService.getCustomerOrderHistory(req.params.customerId);
    const customerStats = orderService.getCustomerHistoryStats(req.params.customerId);

    res.json({
      success: true,
      data: {
        orders: orders.map(order => order.toJSON()),
        statistics: customerStats
      }
    });

  } catch (error) {
    logger.error(`Error fetching customer orders: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * GET /api/analytics/cancellations - Get cancellation analytics
 */
router.get('/analytics/cancellations', async (req, res) => {
  try {
    const analytics = orderService.getCancellationAnalytics();
    
    res.json({
      success: true,
      data: analytics
    });

  } catch (error) {
    logger.error(`Error fetching cancellation analytics: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * POST /api/demo/sample-orders - Generate sample orders for testing
 */
router.post('/demo/sample-orders', async (req, res) => {
  try {
    const orders = await orderService.generateSampleOrders();
    
    res.json({
      success: true,
      message: 'Sample orders created successfully',
      data: orders.map(order => order.toJSON())
    });

  } catch (error) {
    logger.error(`Error creating sample orders: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * POST /api/demo/cancel-sample/:orderId - Cancel a sample order for demo
 */
router.post('/demo/cancel-sample/:orderId', async (req, res) => {
  try {
    const sampleReasons = [
      'Delivery delayed by more than expected time',
      'Found better price at competitor store',
      'Product received poor reviews online',
      'Payment method was declined',
      'Changed mind about the purchase',
      'Product became out of stock',
      'Shipping cost too high for small order'
    ];

    const randomReason = sampleReasons[Math.floor(Math.random() * sampleReasons.length)];
    
    const result = await orderService.cancelOrderWithAnalysis(
      req.params.orderId, 
      randomReason,
      {
        demoMode: true,
        timestamp: new Date().toISOString()
      }
    );

    res.json({
      success: true,
      message: 'Sample order cancelled and analyzed',
      data: result
    });

  } catch (error) {
    logger.error(`Error cancelling sample order: ${error.message}`);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;
