class Order {
  constructor({
    orderId,
    customerId,
    orderDetails,
    totalAmount,
    currency = 'USD',
    orderDate,
    expectedDeliveryDate,
    status = 'pending',
    items = [],
    shippingAddress,
    billingAddress,
    paymentMethod,
    cancellationReason = null,
    cancellationDate = null,
    customerHistory = {}
  }) {
    this.orderId = orderId;
    this.customerId = customerId;
    this.orderDetails = orderDetails;
    this.totalAmount = totalAmount;
    this.currency = currency;
    this.orderDate = orderDate || new Date().toISOString();
    this.expectedDeliveryDate = expectedDeliveryDate;
    this.status = status; // pending, confirmed, shipped, delivered, cancelled
    this.items = items;
    this.shippingAddress = shippingAddress;
    this.billingAddress = billingAddress;
    this.paymentMethod = paymentMethod;
    this.cancellationReason = cancellationReason;
    this.cancellationDate = cancellationDate;
    this.customerHistory = customerHistory;
  }

  cancelOrder(reason, additionalDetails = {}) {
    this.status = 'cancelled';
    this.cancellationReason = reason;
    this.cancellationDate = new Date().toISOString();
    
    // Store additional cancellation details
    this.cancellationDetails = {
      reason: reason,
      timestamp: this.cancellationDate,
      additionalInfo: additionalDetails
    };
  }

  getOrderAge() {
    const orderDate = new Date(this.orderDate);
    const now = new Date();
    return Math.floor((now - orderDate) / (1000 * 60 * 60 * 24)); // days
  }

  getDeliveryTimeRemaining() {
    if (!this.expectedDeliveryDate) return null;
    
    const deliveryDate = new Date(this.expectedDeliveryDate);
    const now = new Date();
    return Math.floor((deliveryDate - now) / (1000 * 60 * 60 * 24)); // days
  }

  toJSON() {
    return {
      orderId: this.orderId,
      customerId: this.customerId,
      orderDetails: this.orderDetails,
      totalAmount: this.totalAmount,
      currency: this.currency,
      orderDate: this.orderDate,
      expectedDeliveryDate: this.expectedDeliveryDate,
      status: this.status,
      items: this.items,
      shippingAddress: this.shippingAddress,
      billingAddress: this.billingAddress,
      paymentMethod: this.paymentMethod,
      cancellationReason: this.cancellationReason,
      cancellationDate: this.cancellationDate,
      orderAge: this.getOrderAge(),
      deliveryTimeRemaining: this.getDeliveryTimeRemaining()
    };
  }
}

module.exports = Order;
