const Order = require('../models/Order');
const OrderCancellationAnalyzer = require('./OrderCancellationAnalyzer');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

class OrderManagementService {
  constructor() {
    this.orders = new Map(); // In-memory storage (replace with database)
    this.customerOrders = new Map(); // Customer ID -> Order IDs mapping
    this.cancellationAnalyzer = new OrderCancellationAnalyzer();
  }

  /**
   * Create a new order
   */
  async createOrder(orderData) {
    try {
      const orderId = orderData.orderId || `ORD_${uuidv4()}`;
      
      const order = new Order({
        ...orderData,
        orderId
      });

      this.orders.set(orderId, order);
      
      // Update customer orders mapping
      if (!this.customerOrders.has(order.customerId)) {
        this.customerOrders.set(order.customerId, []);
      }
      this.customerOrders.get(order.customerId).push(orderId);

      logger.info(`Order created successfully: ${orderId}`);
      return order;
    } catch (error) {
      logger.error(`Error creating order: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get order by ID
   */
  getOrder(orderId) {
    return this.orders.get(orderId);
  }

  /**
   * Get customer's order history
   */
  getCustomerOrderHistory(customerId) {
    const orderIds = this.customerOrders.get(customerId) || [];
    return orderIds.map(id => this.orders.get(id)).filter(order => order);
  }

  /**
   * Cancel an order and perform comprehensive analysis
   */
  async cancelOrderWithAnalysis(orderId, cancellationReason, additionalDetails = {}) {
    try {
      const order = this.orders.get(orderId);
      if (!order) {
        throw new Error(`Order not found: ${orderId}`);
      }

      if (order.status === 'cancelled') {
        throw new Error(`Order ${orderId} is already cancelled`);
      }

      // Cancel the order
      order.cancelOrder(cancellationReason, additionalDetails);

      // Get customer history for analysis
      const customerHistory = this.getCustomerHistoryStats(order.customerId);

      // Perform comprehensive cancellation analysis
      const analysisReport = await this.cancellationAnalyzer.analyzeOrderCancellation(
        order, 
        customerHistory
      );

      // Update order with analysis results
      order.analysisReport = analysisReport;

      logger.info(`Order cancelled and analyzed: ${orderId}`);
      
      return {
        order: order.toJSON(),
        analysisReport
      };

    } catch (error) {
      logger.error(`Error cancelling order ${orderId}: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get customer history statistics
   */
  getCustomerHistoryStats(customerId) {
    const orders = this.getCustomerOrderHistory(customerId);
    
    const stats = {
      totalOrders: orders.length,
      cancelledOrders: orders.filter(order => order.status === 'cancelled').length,
      completedOrders: orders.filter(order => order.status === 'delivered').length,
      totalValue: orders.reduce((sum, order) => sum + order.totalAmount, 0),
      averageOrderValue: 0,
      lastOrderDate: null,
      commonCancellationReasons: {}
    };

    if (stats.totalOrders > 0) {
      stats.averageOrderValue = stats.totalValue / stats.totalOrders;
      
      // Find last order date
      const sortedOrders = orders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate));
      stats.lastOrderDate = sortedOrders[0]?.orderDate;

      // Analyze common cancellation reasons
      orders
        .filter(order => order.status === 'cancelled' && order.cancellationReason)
        .forEach(order => {
          const reason = order.cancellationReason.toLowerCase();
          stats.commonCancellationReasons[reason] = (stats.commonCancellationReasons[reason] || 0) + 1;
        });
    }

    return stats;
  }

  /**
   * Get detailed order analysis
   */
  async getOrderAnalysis(orderId) {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new Error(`Order not found: ${orderId}`);
    }

    // If order is cancelled and has analysis, return existing analysis
    if (order.status === 'cancelled' && order.analysisReport) {
      return order.analysisReport;
    }

    // For non-cancelled orders, perform risk analysis
    const customerHistory = this.getCustomerHistoryStats(order.customerId);
    
    return {
      order: order.toJSON(),
      customerHistory,
      riskAssessment: await this.assessOrderRisk(order, customerHistory)
    };
  }

  /**
   * Assess risk of order cancellation for active orders
   */
  async assessOrderRisk(order, customerHistory) {
    // Calculate risk factors
    const riskFactors = {
      customerCancellationRate: customerHistory.totalOrders > 0 ? 
        customerHistory.cancelledOrders / customerHistory.totalOrders : 0,
      orderAge: order.getOrderAge(),
      orderValue: order.totalAmount,
      deliveryDelay: order.getDeliveryTimeRemaining() < 0 ? Math.abs(order.getDeliveryTimeRemaining()) : 0,
      orderComplexity: order.items.length
    };

    // Calculate overall risk score
    let riskScore = 0;
    
    // Customer history factor (40% weight)
    riskScore += riskFactors.customerCancellationRate * 0.4;
    
    // Order age factor (25% weight)
    if (riskFactors.orderAge > 7) riskScore += 0.25;
    else if (riskFactors.orderAge > 3) riskScore += 0.15;
    
    // Delivery delay factor (20% weight)
    if (riskFactors.deliveryDelay > 0) {
      riskScore += Math.min(riskFactors.deliveryDelay / 7, 1) * 0.2;
    }
    
    // Order complexity factor (15% weight)
    if (riskFactors.orderComplexity > 5) riskScore += 0.15;
    else if (riskFactors.orderComplexity > 2) riskScore += 0.08;

    const finalRiskScore = Math.min(riskScore, 1);

    return {
      riskScore: Math.round(finalRiskScore * 100),
      riskLevel: this.getRiskLevel(finalRiskScore),
      riskFactors,
      recommendations: this.getRiskRecommendations(finalRiskScore, riskFactors),
      actionRequired: finalRiskScore > 0.6
    };
  }

  getRiskLevel(riskScore) {
    if (riskScore >= 0.7) return 'High Risk';
    if (riskScore >= 0.4) return 'Medium Risk';
    return 'Low Risk';
  }

  getRiskRecommendations(riskScore, factors) {
    const recommendations = [];

    if (riskScore > 0.7) {
      recommendations.push('Contact customer proactively');
      recommendations.push('Provide order status update');
      recommendations.push('Offer customer support assistance');
    }

    if (factors.deliveryDelay > 0) {
      recommendations.push('Address delivery delay immediately');
      recommendations.push('Provide updated delivery timeline');
    }

    if (factors.customerCancellationRate > 0.3) {
      recommendations.push('Review customer satisfaction');
      recommendations.push('Consider loyalty incentives');
    }

    if (factors.orderAge > 7) {
      recommendations.push('Expedite order processing');
      recommendations.push('Provide tracking information');
    }

    return recommendations;
  }

  /**
   * Get cancellation analytics dashboard data
   */
  getCancellationAnalytics() {
    const allOrders = Array.from(this.orders.values());
    const cancelledOrders = allOrders.filter(order => order.status === 'cancelled');

    const analytics = {
      totalOrders: allOrders.length,
      totalCancellations: cancelledOrders.length,
      cancellationRate: allOrders.length > 0 ? (cancelledOrders.length / allOrders.length * 100).toFixed(2) : 0,
      topCancellationReasons: {},
      cancellationsByMonth: {},
      averageOrderValueCancelled: 0,
      totalRevenueLost: 0
    };

    if (cancelledOrders.length > 0) {
      // Calculate revenue impact
      analytics.totalRevenueLost = cancelledOrders.reduce((sum, order) => sum + order.totalAmount, 0);
      analytics.averageOrderValueCancelled = analytics.totalRevenueLost / cancelledOrders.length;

      // Analyze cancellation reasons
      cancelledOrders.forEach(order => {
        if (order.cancellationReason) {
          const reason = order.cancellationReason.toLowerCase();
          analytics.topCancellationReasons[reason] = (analytics.topCancellationReasons[reason] || 0) + 1;
        }

        // Group by month
        const month = new Date(order.cancellationDate).toISOString().substring(0, 7); // YYYY-MM
        analytics.cancellationsByMonth[month] = (analytics.cancellationsByMonth[month] || 0) + 1;
      });
    }

    return analytics;
  }

  /**
   * Generate sample orders for testing
   */
  async generateSampleOrders() {
    const sampleOrders = [
      {
        customerId: 'CUST_001',
        orderDetails: 'Electronics Bundle - Laptop, Mouse, Keyboard',
        totalAmount: 1299.99,
        items: [
          { name: 'Gaming Laptop', price: 999.99, quantity: 1 },
          { name: 'Wireless Mouse', price: 149.99, quantity: 1 },
          { name: 'Mechanical Keyboard', price: 150.01, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Mumbai', state: 'Maharashtra', country: 'India' },
        paymentMethod: 'Credit Card'
      },
      {
        customerId: 'CUST_002',
        orderDetails: 'Fashion Items',
        totalAmount: 299.99,
        items: [
          { name: 'Casual Shirt', price: 149.99, quantity: 1 },
          { name: 'Jeans', price: 150.00, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Delhi', state: 'Delhi', country: 'India' },
        paymentMethod: 'UPI'
      },
      {
        customerId: 'CUST_003',
        orderDetails: 'Books and Stationery',
        totalAmount: 89.99,
        items: [
          { name: 'Programming Book', price: 59.99, quantity: 1 },
          { name: 'Notebook Set', price: 30.00, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Bangalore', state: 'Karnataka', country: 'India' },
        paymentMethod: 'Debit Card'
      }
    ];

    const createdOrders = [];
    for (const orderData of sampleOrders) {
      try {
        const order = await this.createOrder(orderData);
        createdOrders.push(order);
      } catch (error) {
        logger.error(`Error creating sample order: ${error.message}`);
      }
    }

    return createdOrders;
  }
}

module.exports = OrderManagementService;
