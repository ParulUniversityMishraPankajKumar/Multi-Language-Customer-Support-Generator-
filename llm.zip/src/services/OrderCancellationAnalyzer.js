const Order = require('../models/Order');
const logger = require('../utils/logger');

class OrderCancellationAnalyzer {
  constructor() {
    this.cancellationPatterns = {
      // Common cancellation reasons and their risk factors
      'delivery_delay': { riskScore: 0.8, category: 'logistics' },
      'product_unavailable': { riskScore: 0.9, category: 'inventory' },
      'payment_failed': { riskScore: 0.7, category: 'payment' },
      'changed_mind': { riskScore: 0.4, category: 'customer_preference' },
      'found_better_price': { riskScore: 0.6, category: 'pricing' },
      'poor_reviews': { riskScore: 0.8, category: 'product_quality' },
      'shipping_cost': { riskScore: 0.5, category: 'pricing' },
      'technical_issues': { riskScore: 0.7, category: 'platform' },
      'duplicate_order': { riskScore: 0.2, category: 'user_error' }
    };
  }

  /**
   * Main function to analyze order cancellation
   * @param {Order} order - The cancelled order object
   * @param {Object} customerHistory - Customer's historical data
   * @returns {Object} - Detailed analysis and prediction
   */
  async analyzeOrderCancellation(order, customerHistory = {}) {
    try {
      logger.info(`Starting cancellation analysis for order: ${order.orderId}`);

      // Step 1: Extract order details
      const orderDetails = this.extractOrderDetails(order);

      // Step 2: Analyze cancellation reason
      const reasonAnalysis = this.analyzeCancellationReason(order.cancellationReason);

      // Step 3: Identify and explain the problem
      const problemAnalysis = await this.identifyProblem(order, customerHistory);

      // Step 4: Predict future cancellation probability
      const futurePrediction = this.predictFutureCancellation(order, customerHistory, reasonAnalysis);

      // Step 5: Generate comprehensive report
      const report = this.generateAnalysisReport({
        orderDetails,
        reasonAnalysis,
        problemAnalysis,
        futurePrediction,
        order,
        customerHistory
      });

      logger.info(`Cancellation analysis completed for order: ${order.orderId}`);
      return report;

    } catch (error) {
      logger.error(`Error analyzing order cancellation: ${error.message}`);
      throw error;
    }
  }

  /**
   * Extract comprehensive order details
   */
  extractOrderDetails(order) {
    return {
      orderId: order.orderId,
      customerId: order.customerId,
      orderValue: order.totalAmount,
      currency: order.currency,
      orderDate: order.orderDate,
      cancellationDate: order.cancellationDate,
      orderAge: order.getOrderAge(),
      deliveryTimeRemaining: order.getDeliveryTimeRemaining(),
      itemCount: order.items.length,
      paymentMethod: order.paymentMethod,
      shippingAddress: order.shippingAddress,
      orderStatus: order.status
    };
  }

  /**
   * Analyze the specific cancellation reason
   */
  analyzeCancellationReason(reason) {
    const normalizedReason = reason?.toLowerCase() || 'unknown';
    
    // Find matching pattern
    let matchedPattern = null;
    let confidence = 0;

    for (const [pattern, details] of Object.entries(this.cancellationPatterns)) {
      if (normalizedReason.includes(pattern.replace('_', ' ')) || 
          normalizedReason.includes(pattern)) {
        matchedPattern = pattern;
        confidence = 0.9;
        break;
      }
    }

    // If no exact match, try fuzzy matching
    if (!matchedPattern) {
      matchedPattern = this.fuzzyMatchReason(normalizedReason);
      confidence = 0.6;
    }

    const patternDetails = this.cancellationPatterns[matchedPattern] || 
                          { riskScore: 0.5, category: 'unknown' };

    return {
      originalReason: reason,
      normalizedReason,
      matchedPattern,
      confidence,
      riskScore: patternDetails.riskScore,
      category: patternDetails.category,
      severity: this.getSeverityLevel(patternDetails.riskScore)
    };
  }

  /**
   * Fuzzy match cancellation reason when exact match not found
   */
  fuzzyMatchReason(reason) {
    // Simple keyword matching for common scenarios
    if (reason.includes('delay') || reason.includes('late')) return 'delivery_delay';
    if (reason.includes('stock') || reason.includes('available')) return 'product_unavailable';
    if (reason.includes('payment') || reason.includes('card')) return 'payment_failed';
    if (reason.includes('price') || reason.includes('cost')) return 'found_better_price';
    if (reason.includes('review') || reason.includes('rating')) return 'poor_reviews';
    if (reason.includes('shipping') || reason.includes('delivery')) return 'shipping_cost';
    if (reason.includes('technical') || reason.includes('error')) return 'technical_issues';
    
    return 'changed_mind'; // default fallback
  }

  /**
   * Identify and explain the core problem
   */
  async identifyProblem(order, customerHistory) {
    const problems = [];
    const recommendations = [];

    // Analyze based on cancellation reason
    const reasonAnalysis = this.analyzeCancellationReason(order.cancellationReason);
    
    switch (reasonAnalysis.category) {
      case 'logistics':
        problems.push({
          type: 'Delivery Issues',
          description: 'Customer cancelled due to delivery delays or logistics problems',
          impact: 'High customer dissatisfaction and potential future order avoidance',
          rootCause: 'Supply chain or logistics partner inefficiencies'
        });
        recommendations.push('Improve delivery time estimates and communication');
        recommendations.push('Consider alternative shipping partners');
        break;

      case 'inventory':
        problems.push({
          type: 'Inventory Management',
          description: 'Product became unavailable after order placement',
          impact: 'Lost sale and damaged customer trust',
          rootCause: 'Poor inventory tracking or overselling'
        });
        recommendations.push('Implement real-time inventory management');
        recommendations.push('Set up inventory alerts for popular items');
        break;

      case 'payment':
        problems.push({
          type: 'Payment Processing',
          description: 'Payment failed during processing',
          impact: 'Order cancellation and potential customer churn',
          rootCause: 'Payment gateway issues or customer payment method problems'
        });
        recommendations.push('Provide multiple payment options');
        recommendations.push('Improve payment failure communication');
        break;

      case 'pricing':
        problems.push({
          type: 'Competitive Pricing',
          description: 'Customer found better pricing elsewhere or shipping costs too high',
          impact: 'Price sensitivity leading to cancellation',
          rootCause: 'Non-competitive pricing or hidden costs'
        });
        recommendations.push('Review pricing strategy');
        recommendations.push('Consider free shipping thresholds');
        break;

      case 'product_quality':
        problems.push({
          type: 'Product Perception',
          description: 'Poor reviews or product quality concerns',
          impact: 'Trust issues affecting purchase decisions',
          rootCause: 'Product quality issues or inadequate product information'
        });
        recommendations.push('Improve product descriptions and images');
        recommendations.push('Address product quality issues');
        break;
    }

    // Customer-specific analysis
    if (customerHistory.totalOrders > 0) {
      const cancellationRate = (customerHistory.cancelledOrders || 0) / customerHistory.totalOrders;
      if (cancellationRate > 0.3) {
        problems.push({
          type: 'Customer Pattern',
          description: 'High cancellation rate for this customer',
          impact: 'Potential customer churn risk',
          rootCause: 'Recurring issues or customer behavior pattern'
        });
        recommendations.push('Provide personalized customer support');
        recommendations.push('Investigate customer-specific issues');
      }
    }

    return {
      identifiedProblems: problems,
      recommendations,
      analysisDate: new Date().toISOString()
    };
  }

  /**
   * Predict future cancellation probability
   */
  predictFutureCancellation(order, customerHistory, reasonAnalysis) {
    let baseProbability = reasonAnalysis.riskScore;
    
    // Adjust based on customer history
    if (customerHistory.totalOrders > 0) {
      const cancellationRate = (customerHistory.cancelledOrders || 0) / customerHistory.totalOrders;
      baseProbability = (baseProbability + cancellationRate) / 2;
    }

    // Adjust based on order characteristics
    if (order.totalAmount > 1000) baseProbability += 0.1; // Higher value orders
    if (order.getOrderAge() > 7) baseProbability += 0.15; // Older orders
    if (order.items.length > 5) baseProbability += 0.05; // Complex orders

    // Normalize probability
    const finalProbability = Math.min(Math.max(baseProbability, 0), 1);

    return {
      cancellationProbability: Math.round(finalProbability * 100),
      confidenceLevel: this.getConfidenceLevel(finalProbability),
      riskLevel: this.getRiskLevel(finalProbability),
      factors: {
        reasonRisk: reasonAnalysis.riskScore,
        customerHistory: customerHistory.totalOrders > 0 ? 
          (customerHistory.cancelledOrders || 0) / customerHistory.totalOrders : 0,
        orderComplexity: this.calculateOrderComplexity(order)
      },
      recommendations: this.getPredictionRecommendations(finalProbability, reasonAnalysis.category)
    };
  }

  /**
   * Calculate order complexity score
   */
  calculateOrderComplexity(order) {
    let complexity = 0;
    complexity += order.items.length * 0.1;
    complexity += order.totalAmount > 1000 ? 0.2 : 0;
    complexity += order.getOrderAge() > 7 ? 0.3 : 0;
    return Math.min(complexity, 1);
  }

  /**
   * Get prediction-based recommendations
   */
  getPredictionRecommendations(probability, category) {
    const recommendations = [];
    
    if (probability > 0.7) {
      recommendations.push('High-risk customer: Implement proactive retention strategies');
      recommendations.push('Provide priority customer support');
      recommendations.push('Consider offering incentives for future orders');
    } else if (probability > 0.4) {
      recommendations.push('Medium-risk customer: Monitor future order patterns');
      recommendations.push('Send order confirmation and tracking updates');
    } else {
      recommendations.push('Low-risk customer: Standard order processing');
    }

    // Category-specific recommendations
    if (category === 'logistics') {
      recommendations.push('Provide detailed shipping tracking');
      recommendations.push('Set realistic delivery expectations');
    } else if (category === 'pricing') {
      recommendations.push('Consider personalized pricing or discounts');
      recommendations.push('Highlight value propositions');
    }

    return recommendations;
  }

  /**
   * Generate comprehensive analysis report
   */
  generateAnalysisReport(data) {
    const { orderDetails, reasonAnalysis, problemAnalysis, futurePrediction, order, customerHistory } = data;

    return {
      analysisId: `analysis_${order.orderId}_${Date.now()}`,
      timestamp: new Date().toISOString(),
      orderSummary: {
        orderId: orderDetails.orderId,
        customerId: orderDetails.customerId,
        orderValue: `${orderDetails.orderValue} ${orderDetails.currency}`,
        cancellationDate: orderDetails.cancellationDate,
        orderAge: `${orderDetails.orderAge} days`
      },
      cancellationAnalysis: {
        reason: reasonAnalysis.originalReason,
        category: reasonAnalysis.category,
        severity: reasonAnalysis.severity,
        confidence: `${Math.round(reasonAnalysis.confidence * 100)}%`,
        riskScore: reasonAnalysis.riskScore
      },
      problemIdentification: {
        mainProblems: problemAnalysis.identifiedProblems,
        recommendations: problemAnalysis.recommendations
      },
      futurePrediction: {
        cancellationProbability: `${futurePrediction.cancellationProbability}%`,
        riskLevel: futurePrediction.riskLevel,
        confidenceLevel: futurePrediction.confidenceLevel,
        keyFactors: futurePrediction.factors,
        recommendations: futurePrediction.recommendations
      },
      customerInsights: {
        totalOrders: customerHistory.totalOrders || 0,
        previousCancellations: customerHistory.cancelledOrders || 0,
        loyaltyScore: this.calculateLoyaltyScore(customerHistory),
        riskProfile: this.getCustomerRiskProfile(customerHistory)
      },
      actionItems: this.generateActionItems(reasonAnalysis, futurePrediction)
    };
  }

  /**
   * Helper methods
   */
  getSeverityLevel(riskScore) {
    if (riskScore >= 0.8) return 'High';
    if (riskScore >= 0.5) return 'Medium';
    return 'Low';
  }

  getConfidenceLevel(probability) {
    if (probability >= 0.8) return 'High';
    if (probability >= 0.5) return 'Medium';
    return 'Low';
  }

  getRiskLevel(probability) {
    if (probability >= 0.7) return 'High Risk';
    if (probability >= 0.4) return 'Medium Risk';
    return 'Low Risk';
  }

  calculateLoyaltyScore(customerHistory) {
    if (!customerHistory.totalOrders) return 0;
    
    const completionRate = ((customerHistory.totalOrders - (customerHistory.cancelledOrders || 0)) / customerHistory.totalOrders);
    const orderFrequency = customerHistory.totalOrders / 12; // assuming 12 months
    
    return Math.round((completionRate * 0.7 + Math.min(orderFrequency / 5, 1) * 0.3) * 100);
  }

  getCustomerRiskProfile(customerHistory) {
    const loyaltyScore = this.calculateLoyaltyScore(customerHistory);
    
    if (loyaltyScore >= 80) return 'Low Risk - Loyal Customer';
    if (loyaltyScore >= 50) return 'Medium Risk - Regular Customer';
    if (loyaltyScore >= 20) return 'High Risk - Occasional Customer';
    return 'Very High Risk - New/Problematic Customer';
  }

  generateActionItems(reasonAnalysis, futurePrediction) {
    const actions = [];
    
    // Immediate actions based on cancellation reason
    if (reasonAnalysis.category === 'logistics') {
      actions.push({
        priority: 'High',
        action: 'Contact logistics team to investigate delivery delays',
        timeline: 'Immediate'
      });
    }
    
    if (reasonAnalysis.category === 'payment') {
      actions.push({
        priority: 'High',
        action: 'Review payment processing system',
        timeline: '24 hours'
      });
    }

    // Future prevention actions
    if (futurePrediction.cancellationProbability > 70) {
      actions.push({
        priority: 'High',
        action: 'Implement customer retention strategy',
        timeline: 'Before next order'
      });
    }

    actions.push({
      priority: 'Medium',
      action: 'Update customer profile with cancellation insights',
      timeline: '48 hours'
    });

    return actions;
  }
}

module.exports = OrderCancellationAnalyzer;
