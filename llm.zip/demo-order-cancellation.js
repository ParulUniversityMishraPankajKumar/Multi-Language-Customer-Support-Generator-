#!/usr/bin/env node

/**
 * AI Order Cancellation Analysis Demo
 * यह script दिखाती है कि कैसे AI system order cancellation को analyze करके future predictions देता है
 */

const OrderManagementService = require('./src/services/OrderManagementService');
const logger = require('./src/utils/logger');

class OrderCancellationDemo {
  constructor() {
    this.orderService = new OrderManagementService();
    this.demoData = this.generateDemoData();
  }

  generateDemoData() {
    return {
      customers: [
        {
          id: 'CUST_DEMO_001',
          name: 'राज शर्मा',
          email: 'raj.sharma@email.com',
          history: { totalOrders: 15, cancelledOrders: 2, completedOrders: 13 }
        },
        {
          id: 'CUST_DEMO_002', 
          name: 'प्रिया पटेल',
          email: 'priya.patel@email.com',
          history: { totalOrders: 8, cancelledOrders: 4, completedOrders: 4 }
        },
        {
          id: 'CUST_DEMO_003',
          name: 'अमित कुमार',
          email: 'amit.kumar@email.com',
          history: { totalOrders: 3, cancelledOrders: 0, completedOrders: 3 }
        }
      ],
      orders: [
        {
          customerId: 'CUST_DEMO_001',
          orderDetails: 'Electronics Bundle - Gaming Setup',
          totalAmount: 75000,
          currency: 'INR',
          items: [
            { name: 'Gaming Laptop ASUS ROG', price: 65000, quantity: 1 },
            { name: 'Gaming Mouse Logitech', price: 5000, quantity: 1 },
            { name: 'Mechanical Keyboard', price: 5000, quantity: 1 }
          ],
          expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          shippingAddress: { 
            city: 'मुंबई', 
            state: 'महाराष्ट्र', 
            country: 'भारत',
            pincode: '400001'
          },
          paymentMethod: 'Credit Card'
        },
        {
          customerId: 'CUST_DEMO_002',
          orderDetails: 'Fashion & Lifestyle Products',
          totalAmount: 8500,
          currency: 'INR',
          items: [
            { name: 'Designer Kurta Set', price: 3500, quantity: 1 },
            { name: 'Ethnic Jewelry', price: 2500, quantity: 1 },
            { name: 'Leather Handbag', price: 2500, quantity: 1 }
          ],
          expectedDeliveryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
          shippingAddress: { 
            city: 'दिल्ली', 
            state: 'दिल्ली', 
            country: 'भारत',
            pincode: '110001'
          },
          paymentMethod: 'UPI'
        },
        {
          customerId: 'CUST_DEMO_003',
          orderDetails: 'Books & Educational Material',
          totalAmount: 2500,
          currency: 'INR',
          items: [
            { name: 'Programming Books Set', price: 1500, quantity: 1 },
            { name: 'Online Course Subscription', price: 1000, quantity: 1 }
          ],
          expectedDeliveryDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
          shippingAddress: { 
            city: 'बैंगलोर', 
            state: 'कर्नाटक', 
            country: 'भारत',
            pincode: '560001'
          },
          paymentMethod: 'Debit Card'
        }
      ],
      cancellationScenarios: [
        {
          reason: 'Delivery में 5 दिन की देरी हो गई है, urgent need था',
          category: 'logistics',
          additionalDetails: {
            expectedDelay: '5 days',
            customerCommunicated: false,
            urgencyLevel: 'high'
          }
        },
        {
          reason: 'Same product दूसरी website पर 15% कम price में मिल गया',
          category: 'pricing', 
          additionalDetails: {
            competitorPrice: 7225,
            priceDifference: 1275,
            competitorWebsite: 'competitor.com'
          }
        },
        {
          reason: 'Payment gateway में technical issue, card repeatedly decline हो रहा',
          category: 'payment',
          additionalDetails: {
            paymentGateway: 'Razorpay',
            errorCode: 'CARD_DECLINED',
            attemptCount: 3
          }
        }
      ]
    };
  }

  async runDemo() {
    console.log('\n🤖 AI-Powered Order Cancellation Analysis System Demo');
    console.log('=' .repeat(70));
    
    try {
      // Step 1: Create demo orders
      console.log('\n📦 Step 1: Creating Demo Orders...');
      const createdOrders = await this.createDemoOrders();
      
      // Step 2: Show initial risk assessment
      console.log('\n🔍 Step 2: Initial Risk Assessment...');
      await this.showInitialRiskAssessment(createdOrders);
      
      // Step 3: Simulate order cancellations with AI analysis
      console.log('\n❌ Step 3: Order Cancellation Analysis...');
      await this.simulateCancellations(createdOrders);
      
      // Step 4: Show comprehensive analytics
      console.log('\n📊 Step 4: Analytics Dashboard...');
      await this.showAnalyticsDashboard();
      
      // Step 5: Future predictions demo
      console.log('\n🔮 Step 5: Future Prediction Examples...');
      await this.showFuturePredictions();
      
      console.log('\n✅ Demo completed successfully!');
      console.log('\n💡 Key Features Demonstrated:');
      console.log('   • Order details extraction और analysis');
      console.log('   • Cancellation reason की intelligent categorization');
      console.log('   • Problem identification और root cause analysis');
      console.log('   • Future cancellation probability prediction');
      console.log('   • Customer behavior pattern analysis');
      console.log('   • Actionable recommendations generation');
      
    } catch (error) {
      console.error('\n❌ Demo failed:', error.message);
      logger.error('Demo error:', error);
    }
  }

  async createDemoOrders() {
    const createdOrders = [];
    
    for (let i = 0; i < this.demoData.orders.length; i++) {
      const orderData = this.demoData.orders[i];
      const customer = this.demoData.customers[i];
      
      const order = await this.orderService.createOrder(orderData);
      createdOrders.push(order);
      
      console.log(`   ✓ Order ${order.orderId} created for ${customer.name}`);
      console.log(`     Amount: ₹${order.totalAmount} | Items: ${order.items.length}`);
    }
    
    return createdOrders;
  }

  async showInitialRiskAssessment(orders) {
    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];
      const customer = this.demoData.customers[i];
      
      const analysis = await this.orderService.getOrderAnalysis(order.orderId);
      
      console.log(`\n   🎯 Order ${order.orderId} (${customer.name}):`);
      console.log(`      Risk Level: ${analysis.riskAssessment.riskLevel}`);
      console.log(`      Risk Score: ${analysis.riskAssessment.riskScore}%`);
      console.log(`      Customer History: ${customer.history.totalOrders} orders, ${customer.history.cancelledOrders} cancelled`);
      
      if (analysis.riskAssessment.actionRequired) {
        console.log(`      ⚠️  Action Required: High-risk order detected`);
      }
    }
  }

  async simulateCancellations(orders) {
    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];
      const customer = this.demoData.customers[i];
      const scenario = this.demoData.cancellationScenarios[i];
      
      console.log(`\n   📋 Cancelling Order ${order.orderId} (${customer.name})`);
      console.log(`      Reason: "${scenario.reason}"`);
      
      const result = await this.orderService.cancelOrderWithAnalysis(
        order.orderId,
        scenario.reason,
        scenario.additionalDetails
      );
      
      const report = result.analysisReport;
      
      console.log('\n   🔬 AI Analysis Results:');
      console.log('   ─'.repeat(50));
      
      // Order Summary
      console.log(`   📊 Order Summary:`);
      console.log(`      • Order Value: ₹${report.orderSummary.orderValue}`);
      console.log(`      • Order Age: ${report.orderSummary.orderAge}`);
      console.log(`      • Customer: ${customer.name}`);
      
      // Cancellation Analysis
      console.log(`\n   🔍 Cancellation Analysis:`);
      console.log(`      • Category: ${report.cancellationAnalysis.category}`);
      console.log(`      • Severity: ${report.cancellationAnalysis.severity}`);
      console.log(`      • Confidence: ${report.cancellationAnalysis.confidence}`);
      console.log(`      • Risk Score: ${report.cancellationAnalysis.riskScore}`);
      
      // Problem Identification
      console.log(`\n   ⚠️  Identified Problems:`);
      report.problemIdentification.mainProblems.forEach((problem, idx) => {
        console.log(`      ${idx + 1}. ${problem.type}: ${problem.description}`);
        console.log(`         Impact: ${problem.impact}`);
      });
      
      // Future Prediction
      console.log(`\n   🔮 Future Prediction:`);
      console.log(`      • Cancellation Probability: ${report.futurePrediction.cancellationProbability}`);
      console.log(`      • Risk Level: ${report.futurePrediction.riskLevel}`);
      console.log(`      • Confidence Level: ${report.futurePrediction.confidenceLevel}`);
      
      // Recommendations
      console.log(`\n   💡 AI Recommendations:`);
      report.problemIdentification.recommendations.forEach((rec, idx) => {
        console.log(`      ${idx + 1}. ${rec}`);
      });
      
      // Action Items
      console.log(`\n   📋 Action Items:`);
      report.actionItems.forEach((action, idx) => {
        console.log(`      ${idx + 1}. [${action.priority}] ${action.action} (${action.timeline})`);
      });
      
      console.log('\n   ═'.repeat(70));
    }
  }

  async showAnalyticsDashboard() {
    const analytics = this.orderService.getCancellationAnalytics();
    
    console.log('\n   📈 Cancellation Analytics Dashboard:');
    console.log('   ─'.repeat(50));
    console.log(`   • Total Orders: ${analytics.totalOrders}`);
    console.log(`   • Total Cancellations: ${analytics.totalCancellations}`);
    console.log(`   • Cancellation Rate: ${analytics.cancellationRate}%`);
    console.log(`   • Revenue Lost: ₹${analytics.totalRevenueLost.toFixed(2)}`);
    console.log(`   • Average Cancelled Order Value: ₹${analytics.averageOrderValueCancelled.toFixed(2)}`);
    
    console.log('\n   🏷️  Top Cancellation Reasons:');
    Object.entries(analytics.topCancellationReasons)
      .sort(([,a], [,b]) => b - a)
      .forEach(([reason, count], idx) => {
        console.log(`      ${idx + 1}. ${reason}: ${count} orders`);
      });
  }

  async showFuturePredictions() {
    console.log('\n   🔮 Future Prediction Scenarios:');
    console.log('   ─'.repeat(50));
    
    const predictionScenarios = [
      {
        scenario: 'नया customer, पहला high-value order',
        customerHistory: { totalOrders: 1, cancelledOrders: 0 },
        orderValue: 50000,
        predictedRisk: 'Medium (45%)'
      },
      {
        scenario: 'Loyal customer, लेकिन recent में 2 cancellations',
        customerHistory: { totalOrders: 20, cancelledOrders: 3 },
        orderValue: 15000,
        predictedRisk: 'Low-Medium (35%)'
      },
      {
        scenario: 'High-risk customer, multiple past cancellations',
        customerHistory: { totalOrders: 10, cancelledOrders: 6 },
        orderValue: 8000,
        predictedRisk: 'High (78%)'
      }
    ];
    
    predictionScenarios.forEach((scenario, idx) => {
      console.log(`\n   ${idx + 1}. ${scenario.scenario}:`);
      console.log(`      • Order Value: ₹${scenario.orderValue}`);
      console.log(`      • Customer History: ${scenario.customerHistory.totalOrders} orders, ${scenario.customerHistory.cancelledOrders} cancelled`);
      console.log(`      • 🎯 Predicted Cancellation Risk: ${scenario.predictedRisk}`);
      
      if (scenario.predictedRisk.includes('High')) {
        console.log(`      • 🚨 Recommended Actions:`);
        console.log(`        - Proactive customer communication`);
        console.log(`        - Priority customer support`);
        console.log(`        - Consider retention incentives`);
      }
    });
  }
}

// Run demo if called directly
if (require.main === module) {
  const demo = new OrderCancellationDemo();
  demo.runDemo().catch(console.error);
}

module.exports = OrderCancellationDemo;
