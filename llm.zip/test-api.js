#!/usr/bin/env node

/**
 * API Testing Script - Manual testing के लिए
 * यह script सभी API endpoints को test करके results दिखाती है
 */

const axios = require('axios');

const BASE_URL = 'http://localhost:3000';

class APITester {
  constructor() {
    this.baseURL = BASE_URL;
  }

  async testAPI() {
    console.log('🧪 API Testing Started...');
    console.log('=' .repeat(50));

    try {
      // Test 1: Home endpoint
      await this.testHomeEndpoint();
      
      // Test 2: Create Order
      const orderId = await this.testCreateOrder();
      
      // Test 3: Get Order Details
      await this.testGetOrder(orderId);
      
      // Test 4: Cancel Order with Analysis
      await this.testCancelOrder(orderId);
      
      // Test 5: Get Analytics
      await this.testGetAnalytics();
      
      // Test 6: Create Sample Orders
      await this.testCreateSampleOrders();
      
      console.log('\n✅ All API tests completed successfully!');
      
    } catch (error) {
      console.error('\n❌ API Test failed:', error.message);
    }
  }

  async testHomeEndpoint() {
    console.log('\n1. Testing Home Endpoint...');
    try {
      const response = await axios.get(`${this.baseURL}/`);
      console.log('   ✅ Status:', response.status);
      console.log('   📝 Message:', response.data.message);
      console.log('   🔗 Available Endpoints:', Object.keys(response.data.endpoints).length);
    } catch (error) {
      console.log('   ❌ Failed:', error.message);
    }
  }

  async testCreateOrder() {
    console.log('\n2. Testing Create Order...');
    const orderData = {
      customerId: 'CUST_API_TEST_001',
      orderDetails: 'API Test Order - Electronics',
      totalAmount: 25000,
      currency: 'INR',
      items: [
        { name: 'Smartphone', price: 20000, quantity: 1 },
        { name: 'Phone Case', price: 500, quantity: 1 },
        { name: 'Screen Guard', price: 300, quantity: 1 },
        { name: 'Charger', price: 1200, quantity: 2 }
      ],
      expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      shippingAddress: {
        city: 'नई दिल्ली',
        state: 'दिल्ली',
        country: 'भारत',
        pincode: '110001'
      },
      paymentMethod: 'Credit Card'
    };

    try {
      const response = await axios.post(`${this.baseURL}/api/orders`, orderData);
      console.log('   ✅ Status:', response.status);
      console.log('   📦 Order ID:', response.data.data.orderId);
      console.log('   💰 Amount:', `₹${response.data.data.totalAmount}`);
      console.log('   📅 Created:', response.data.data.orderDate);
      return response.data.data.orderId;
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
      return null;
    }
  }

  async testGetOrder(orderId) {
    if (!orderId) return;
    
    console.log('\n3. Testing Get Order Details...');
    try {
      const response = await axios.get(`${this.baseURL}/api/orders/${orderId}`);
      console.log('   ✅ Status:', response.status);
      console.log('   📦 Order ID:', response.data.data.orderId);
      console.log('   👤 Customer:', response.data.data.customerId);
      console.log('   📊 Status:', response.data.data.status);
      console.log('   🛍️ Items:', response.data.data.items.length);
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }

  async testCancelOrder(orderId) {
    if (!orderId) return;
    
    console.log('\n4. Testing Cancel Order with AI Analysis...');
    const cancellationData = {
      reason: 'Delivery में बहुत ज्यादा delay हो रहा है, 10 दिन हो गए',
      additionalDetails: {
        expectedDelay: '10 days',
        customerCommunicated: true,
        urgencyLevel: 'high',
        alternativeRequested: false
      }
    };

    try {
      const response = await axios.post(`${this.baseURL}/api/orders/${orderId}/cancel`, cancellationData);
      console.log('   ✅ Status:', response.status);
      console.log('   📋 Analysis ID:', response.data.data.analysisReport.analysisId);
      
      const report = response.data.data.analysisReport;
      console.log('\n   🔬 AI Analysis Summary:');
      console.log('   ─'.repeat(40));
      console.log(`   • Category: ${report.cancellationAnalysis.category}`);
      console.log(`   • Severity: ${report.cancellationAnalysis.severity}`);
      console.log(`   • Future Risk: ${report.futurePrediction.cancellationProbability}`);
      console.log(`   • Risk Level: ${report.futurePrediction.riskLevel}`);
      console.log(`   • Problems Found: ${report.problemIdentification.mainProblems.length}`);
      console.log(`   • Recommendations: ${report.problemIdentification.recommendations.length}`);
      console.log(`   • Action Items: ${report.actionItems.length}`);
      
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }

  async testGetAnalytics() {
    console.log('\n5. Testing Analytics Dashboard...');
    try {
      const response = await axios.get(`${this.baseURL}/api/analytics/cancellations`);
      console.log('   ✅ Status:', response.status);
      
      const analytics = response.data.data;
      console.log('\n   📊 Analytics Summary:');
      console.log('   ─'.repeat(40));
      console.log(`   • Total Orders: ${analytics.totalOrders}`);
      console.log(`   • Total Cancellations: ${analytics.totalCancellations}`);
      console.log(`   • Cancellation Rate: ${analytics.cancellationRate}%`);
      console.log(`   • Revenue Lost: ₹${analytics.totalRevenueLost.toFixed(2)}`);
      
      if (Object.keys(analytics.topCancellationReasons).length > 0) {
        console.log('\n   🏷️ Top Cancellation Reasons:');
        Object.entries(analytics.topCancellationReasons)
          .sort(([,a], [,b]) => b - a)
          .slice(0, 3)
          .forEach(([reason, count], idx) => {
            console.log(`     ${idx + 1}. ${reason}: ${count} orders`);
          });
      }
      
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }

  async testCreateSampleOrders() {
    console.log('\n6. Testing Create Sample Orders...');
    try {
      const response = await axios.post(`${this.baseURL}/api/demo/sample-orders`);
      console.log('   ✅ Status:', response.status);
      console.log('   📦 Sample Orders Created:', response.data.data.length);
      
      // Cancel one sample order for demo
      if (response.data.data.length > 0) {
        const sampleOrderId = response.data.data[0].orderId;
        console.log('\n   Testing Sample Order Cancellation...');
        
        const cancelResponse = await axios.post(`${this.baseURL}/api/demo/cancel-sample/${sampleOrderId}`);
        console.log('   ✅ Sample Cancellation Status:', cancelResponse.status);
        console.log('   🔮 Prediction:', cancelResponse.data.data.analysisReport.futurePrediction.cancellationProbability);
      }
      
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }
}

// Customer Support API भी test करते हैं
class SupportAPITester {
  constructor() {
    this.baseURL = BASE_URL;
  }

  async testSupportAPI() {
    console.log('\n🎧 Customer Support API Testing...');
    console.log('=' .repeat(50));

    try {
      await this.testSupportQuery();
      await this.testLanguages();
    } catch (error) {
      console.error('❌ Support API Test failed:', error.message);
    }
  }

  async testSupportQuery() {
    console.log('\n1. Testing Support Query (Hindi)...');
    const queryData = {
      message: 'मेरा order कब deliver होगा? Order ID: ORD123456',
      customerEmail: 'customer@test.com',
      customerName: 'राहुल शर्मा'
    };

    try {
      const response = await axios.post(`${this.baseURL}/api/support/query`, queryData);
      console.log('   ✅ Status:', response.status);
      console.log('   🎫 Ticket ID:', response.data.ticketId);
      console.log('   🌐 Detected Language:', response.data.detectedLanguage);
      console.log('   💬 Response Preview:', response.data.response.substring(0, 100) + '...');
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }

  async testLanguages() {
    console.log('\n2. Testing Supported Languages...');
    try {
      const response = await axios.get(`${this.baseURL}/api/languages`);
      console.log('   ✅ Status:', response.status);
      console.log('   🌐 Total Languages:', Object.keys(response.data).length);
      console.log('   📝 Sample Languages:', Object.keys(response.data).slice(0, 5).join(', '));
    } catch (error) {
      console.log('   ❌ Failed:', error.response?.data?.message || error.message);
    }
  }
}

// Main execution
async function runAllTests() {
  console.log('🚀 Starting Comprehensive API Testing...');
  console.log('Server URL:', BASE_URL);
  console.log('Time:', new Date().toLocaleString());
  
  const orderTester = new APITester();
  await orderTester.testAPI();
  
  const supportTester = new SupportAPITester();
  await supportTester.testSupportAPI();
  
  console.log('\n🎉 All tests completed!');
  console.log('\n💡 अब आप browser में भी check कर सकते हैं:');
  console.log('   🌐 Homepage: http://localhost:3000');
  console.log('   📊 Sample: http://localhost:3000/api/analytics/cancellations');
}

// Run if called directly
if (require.main === module) {
  runAllTests().catch(console.error);
}

module.exports = { APITester, SupportAPITester };
