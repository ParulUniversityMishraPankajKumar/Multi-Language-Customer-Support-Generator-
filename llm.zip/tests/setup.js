// Test setup file
process.env.NODE_ENV = 'test';
process.env.LOG_LEVEL = 'error';

// Global test utilities
global.testTimeout = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Mock external services if needed
jest.setTimeout(10000);
