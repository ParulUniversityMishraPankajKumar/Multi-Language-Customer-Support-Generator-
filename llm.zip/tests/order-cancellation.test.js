const OrderManagementService = require('../src/services/OrderManagementService');
const OrderCancellationAnalyzer = require('../src/services/OrderCancellationAnalyzer');
const Order = require('../src/models/Order');

describe('Order Cancellation Analysis System', () => {
  let orderService;
  let analyzer;

  beforeEach(() => {
    orderService = new OrderManagementService();
    analyzer = new OrderCancellationAnalyzer();
  });

  describe('Order Creation and Management', () => {
    test('should create a new order successfully', async () => {
      const orderData = {
        customerId: 'CUST_TEST_001',
        orderDetails: 'Test Electronics Order',
        totalAmount: 999.99,
        items: [
          { name: 'Laptop', price: 999.99, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Mumbai', state: 'Maharashtra', country: 'India' },
        paymentMethod: 'Credit Card'
      };

      const order = await orderService.createOrder(orderData);
      
      expect(order).toBeDefined();
      expect(order.customerId).toBe('CUST_TEST_001');
      expect(order.totalAmount).toBe(999.99);
      expect(order.status).toBe('pending');
    });

    test('should retrieve order by ID', () => {
      const orderData = {
        orderId: 'TEST_ORDER_001',
        customerId: 'CUST_TEST_001',
        orderDetails: 'Test Order',
        totalAmount: 100.00,
        items: [{ name: 'Test Item', price: 100, quantity: 1 }]
      };

      orderService.createOrder(orderData);
      const retrievedOrder = orderService.getOrder('TEST_ORDER_001');
      
      expect(retrievedOrder).toBeDefined();
      expect(retrievedOrder.orderId).toBe('TEST_ORDER_001');
    });
  });

  describe('Order Cancellation Analysis', () => {
    test('should cancel order and provide comprehensive analysis', async () => {
      // Create test order
      const orderData = {
        orderId: 'CANCEL_TEST_001',
        customerId: 'CUST_CANCEL_001',
        orderDetails: 'High-value Electronics',
        totalAmount: 1299.99,
        items: [
          { name: 'Gaming Laptop', price: 999.99, quantity: 1 },
          { name: 'Mouse', price: 150.00, quantity: 1 },
          { name: 'Keyboard', price: 150.00, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Delhi', state: 'Delhi', country: 'India' },
        paymentMethod: 'Credit Card'
      };

      await orderService.createOrder(orderData);

      // Cancel with analysis
      const result = await orderService.cancelOrderWithAnalysis(
        'CANCEL_TEST_001',
        'Delivery delayed by more than expected time',
        { expectedDelay: '3 days', customerCommunicated: true }
      );

      expect(result).toBeDefined();
      expect(result.order.status).toBe('cancelled');
      expect(result.analysisReport).toBeDefined();
      expect(result.analysisReport.cancellationAnalysis.category).toBe('logistics');
      expect(parseInt(result.analysisReport.futurePrediction.cancellationProbability)).toBeGreaterThan(0);
    });

    test('should analyze different cancellation reasons correctly', async () => {
      const testCases = [
        {
          reason: 'Found better price at competitor',
          expectedCategory: 'pricing'
        },
        {
          reason: 'Product out of stock',
          expectedCategory: 'inventory'
        },
        {
          reason: 'Payment card was declined',
          expectedCategory: 'payment'
        },
        {
          reason: 'Poor product reviews online',
          expectedCategory: 'product_quality'
        }
      ];

      for (let i = 0; i < testCases.length; i++) {
        const testCase = testCases[i];
        const reasonAnalysis = analyzer.analyzeCancellationReason(testCase.reason);
        
        expect(reasonAnalysis.category).toBe(testCase.expectedCategory);
        expect(reasonAnalysis.originalReason).toBe(testCase.reason);
      }
    });

    test('should provide future cancellation predictions', async () => {
      const order = new Order({
        orderId: 'PRED_TEST_001',
        customerId: 'CUST_PRED_001',
        orderDetails: 'Test Order for Prediction',
        totalAmount: 500.00,
        items: [{ name: 'Test Product', price: 500, quantity: 1 }]
      });

      order.cancelOrder('Delivery delayed');

      const customerHistory = {
        totalOrders: 10,
        cancelledOrders: 3,
        completedOrders: 7,
        totalValue: 5000,
        averageOrderValue: 500
      };

      const analysis = await analyzer.analyzeOrderCancellation(order, customerHistory);

      expect(analysis.futurePrediction).toBeDefined();
      expect(parseInt(analysis.futurePrediction.cancellationProbability)).toBeGreaterThan(0);
      expect(parseInt(analysis.futurePrediction.cancellationProbability)).toBeLessThanOrEqual(100);
      expect(analysis.futurePrediction.riskLevel).toBeDefined();
      expect(analysis.futurePrediction.recommendations).toBeInstanceOf(Array);
    });
  });

  describe('Customer History Analysis', () => {
    test('should track customer order history', async () => {
      const customerId = 'CUST_HISTORY_001';
      
      // Create multiple orders for the same customer
      const orderDataList = [
        {
          customerId,
          orderDetails: 'First Order',
          totalAmount: 100.00,
          items: [{ name: 'Item 1', price: 100, quantity: 1 }]
        },
        {
          customerId,
          orderDetails: 'Second Order',
          totalAmount: 200.00,
          items: [{ name: 'Item 2', price: 200, quantity: 1 }]
        },
        {
          customerId,
          orderDetails: 'Third Order',
          totalAmount: 300.00,
          items: [{ name: 'Item 3', price: 300, quantity: 1 }]
        }
      ];

      for (const orderData of orderDataList) {
        await orderService.createOrder(orderData);
      }

      const customerOrders = orderService.getCustomerOrderHistory(customerId);
      const customerStats = orderService.getCustomerHistoryStats(customerId);

      expect(customerOrders).toHaveLength(3);
      expect(customerStats.totalOrders).toBe(3);
      expect(customerStats.totalValue).toBe(600.00);
      expect(customerStats.averageOrderValue).toBe(200.00);
    });

    test('should calculate loyalty score correctly', () => {
      const customerHistory = {
        totalOrders: 10,
        cancelledOrders: 2,
        completedOrders: 8
      };

      const loyaltyScore = analyzer.calculateLoyaltyScore(customerHistory);
      
      expect(loyaltyScore).toBeGreaterThan(0);
      expect(loyaltyScore).toBeLessThanOrEqual(100);
      
      // High completion rate should result in higher loyalty score
      expect(loyaltyScore).toBeGreaterThan(50);
    });
  });

  describe('Risk Assessment', () => {
    test('should assess order cancellation risk for active orders', async () => {
      const orderData = {
        orderId: 'RISK_TEST_001',
        customerId: 'CUST_RISK_001',
        orderDetails: 'Risk Assessment Test Order',
        totalAmount: 750.00,
        items: [{ name: 'Test Product', price: 750, quantity: 1 }],
        expectedDeliveryDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() // 2 days overdue
      };

      const order = await orderService.createOrder(orderData);
      
      const customerHistory = {
        totalOrders: 5,
        cancelledOrders: 2,
        completedOrders: 3
      };

      const riskAssessment = await orderService.assessOrderRisk(order, customerHistory);

      expect(riskAssessment).toBeDefined();
      expect(riskAssessment.riskScore).toBeGreaterThan(0);
      expect(riskAssessment.riskLevel).toBeDefined();
      expect(riskAssessment.recommendations).toBeInstanceOf(Array);
      expect(riskAssessment.actionRequired).toBeDefined();
    });
  });

  describe('Analytics Dashboard', () => {
    test('should generate cancellation analytics', async () => {
      // Create and cancel multiple orders
      const testOrders = [
        {
          customerId: 'CUST_ANALYTICS_001',
          orderDetails: 'Analytics Test Order 1',
          totalAmount: 100.00,
          cancellationReason: 'delivery_delay'
        },
        {
          customerId: 'CUST_ANALYTICS_002',
          orderDetails: 'Analytics Test Order 2',
          totalAmount: 200.00,
          cancellationReason: 'found_better_price'
        },
        {
          customerId: 'CUST_ANALYTICS_003',
          orderDetails: 'Analytics Test Order 3',
          totalAmount: 150.00,
          cancellationReason: 'delivery_delay'
        }
      ];

      for (const orderData of testOrders) {
        const order = await orderService.createOrder(orderData);
        await orderService.cancelOrderWithAnalysis(order.orderId, orderData.cancellationReason);
      }

      const analytics = orderService.getCancellationAnalytics();

      expect(analytics).toBeDefined();
      expect(analytics.totalCancellations).toBeGreaterThan(0);
      expect(parseFloat(analytics.cancellationRate)).toBeGreaterThan(0);
      expect(analytics.topCancellationReasons).toBeDefined();
      expect(analytics.totalRevenueLost).toBeGreaterThan(0);
    });
  });

  describe('Integration Tests', () => {
    test('should handle complete order lifecycle with analysis', async () => {
      // 1. Create order
      const orderData = {
        customerId: 'CUST_INTEGRATION_001',
        orderDetails: 'Integration Test Order',
        totalAmount: 999.99,
        items: [
          { name: 'Premium Product', price: 999.99, quantity: 1 }
        ],
        expectedDeliveryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
        shippingAddress: { city: 'Mumbai', state: 'Maharashtra', country: 'India' },
        paymentMethod: 'Credit Card'
      };

      const order = await orderService.createOrder(orderData);
      expect(order.status).toBe('pending');

      // 2. Get order analysis (risk assessment)
      const preAnalysis = await orderService.getOrderAnalysis(order.orderId);
      expect(preAnalysis.riskAssessment).toBeDefined();

      // 3. Cancel order with comprehensive analysis
      const cancellationResult = await orderService.cancelOrderWithAnalysis(
        order.orderId,
        'Technical issues with payment processing',
        { paymentGateway: 'PayPal', errorCode: 'PP001' }
      );

      expect(cancellationResult.order.status).toBe('cancelled');
      expect(cancellationResult.analysisReport).toBeDefined();
      expect(cancellationResult.analysisReport.cancellationAnalysis.category).toBe('platform');

      // 4. Get post-cancellation analysis
      const postAnalysis = await orderService.getOrderAnalysis(order.orderId);
      expect(postAnalysis.analysisId).toBeDefined();

      // 5. Check analytics update
      const analytics = orderService.getCancellationAnalytics();
      expect(analytics.totalCancellations).toBeGreaterThan(0);
    });
  });
});

describe('Error Handling', () => {
  let orderService;

  beforeEach(() => {
    orderService = new OrderManagementService();
  });

  test('should handle cancellation of non-existent order', async () => {
    await expect(
      orderService.cancelOrderWithAnalysis('NON_EXISTENT_ORDER', 'test reason')
    ).rejects.toThrow('Order not found');
  });

  test('should handle double cancellation', async () => {
    const orderData = {
      orderId: 'DOUBLE_CANCEL_TEST',
      customerId: 'CUST_TEST',
      orderDetails: 'Test Order',
      totalAmount: 100.00,
      items: [{ name: 'Test Item', price: 100, quantity: 1 }]
    };

    const order = await orderService.createOrder(orderData);
    
    // First cancellation should succeed
    await orderService.cancelOrderWithAnalysis(order.orderId, 'First cancellation');
    
    // Second cancellation should fail
    await expect(
      orderService.cancelOrderWithAnalysis(order.orderId, 'Second cancellation')
    ).rejects.toThrow('already cancelled');
  });
});
