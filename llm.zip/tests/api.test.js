const request = require('supertest');
const app = require('../src/index');

describe('Multi-Language Customer Support API', () => {
  describe('GET /', () => {
    it('should return API information', async () => {
      const response = await request(app)
        .get('/')
        .expect(200);

      expect(response.body).toHaveProperty('message');
      expect(response.body).toHaveProperty('version');
      expect(response.body).toHaveProperty('endpoints');
    });
  });

  describe('POST /api/support/query', () => {
    it('should process English support query', async () => {
      const query = {
        message: 'I need help resetting my password',
        customerEmail: 'test@example.com',
        customerName: 'Test User'
      };

      const response = await request(app)
        .post('/api/support/query')
        .send(query)
        .expect(200);

      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('originalMessage', query.message);
      expect(response.body).toHaveProperty('originalLanguage', 'en');
      expect(response.body).toHaveProperty('category', 'password');
      expect(response.body).toHaveProperty('response');
    });

    it('should process Spanish support query', async () => {
      const query = {
        message: '¿Cómo puedo restablecer mi contraseña?',
        customerEmail: 'test@example.com',
        customerName: 'Usuario Prueba'
      };

      const response = await request(app)
        .post('/api/support/query')
        .send(query)
        .expect(200);

      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('originalLanguage', 'es');
      expect(response.body).toHaveProperty('translatedMessage');
      expect(response.body).toHaveProperty('translatedResponse');
    });

    it('should return error for empty message', async () => {
      const query = {
        customerEmail: 'test@example.com'
      };

      const response = await request(app)
        .post('/api/support/query')
        .send(query)
        .expect(400);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('GET /api/languages', () => {
    it('should return supported languages', async () => {
      const response = await request(app)
        .get('/api/languages')
        .expect(200);

      expect(response.body).toHaveProperty('en');
      expect(response.body).toHaveProperty('es');
      expect(response.body).toHaveProperty('fr');
    });
  });

  describe('GET /api/support/analytics', () => {
    it('should return analytics data', async () => {
      const response = await request(app)
        .get('/api/support/analytics')
        .expect(200);

      expect(response.body).toHaveProperty('totalTickets');
      expect(response.body).toHaveProperty('totalCustomers');
      expect(response.body).toHaveProperty('languageDistribution');
      expect(response.body).toHaveProperty('categoryDistribution');
    });
  });

  describe('GET /health', () => {
    it('should return health status', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.body).toHaveProperty('status', 'healthy');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('uptime');
    });
  });
});

describe('Language Detection Service', () => {
  const LanguageDetector = require('../src/services/LanguageDetector');
  const detector = new LanguageDetector();

  test('should detect English correctly', async () => {
    const result = await detector.detectLanguage('Hello, how are you today?');
    expect(result).toBe('en');
  });

  test('should detect Spanish correctly', async () => {
    const result = await detector.detectLanguage('Hola, ¿cómo estás hoy?');
    expect(result).toBe('es');
  });

  test('should detect French correctly', async () => {
    const result = await detector.detectLanguage('Bonjour, comment allez-vous?');
    expect(result).toBe('fr');
  });

  test('should default to English for empty text', async () => {
    const result = await detector.detectLanguage('');
    expect(result).toBe('en');
  });
});

describe('Translation Service', () => {
  const TranslationService = require('../src/services/TranslationService');
  const translator = new TranslationService();

  test('should return same text for same language', async () => {
    const text = 'Hello world';
    const result = await translator.translate(text, 'en', 'en');
    expect(result).toBe(text);
  });

  test('should cache translations', async () => {
    const text = 'Hello';
    await translator.translate(text, 'en', 'es');
    
    const cacheStats = translator.getCacheStats();
    expect(cacheStats.size).toBeGreaterThan(0);
  });

  test('should handle translation errors gracefully', async () => {
    const text = 'Hello world';
    // This should not throw an error even if translation fails
    const result = await translator.translate(text, 'invalid', 'en');
    expect(typeof result).toBe('string');
  });
});

describe('Response Generator Service', () => {
  const ResponseGenerator = require('../src/services/ResponseGenerator');
  const generator = new ResponseGenerator();

  test('should generate password reset response', async () => {
    const response = await generator.generateResponse(
      'I forgot my password', 
      'password', 
      'medium'
    );
    
    expect(response).toContain('password');
    expect(typeof response).toBe('string');
    expect(response.length).toBeGreaterThan(0);
  });

  test('should generate billing response', async () => {
    const response = await generator.generateResponse(
      'Question about my bill', 
      'billing', 
      'high'
    );
    
    expect(response).toContain('billing');
    expect(typeof response).toBe('string');
  });

  test('should handle different priority levels', async () => {
    const urgentResponse = await generator.generateResponse(
      'Emergency help needed', 
      'general', 
      'urgent'
    );
    
    expect(urgentResponse).toContain('urgent');
  });
});
