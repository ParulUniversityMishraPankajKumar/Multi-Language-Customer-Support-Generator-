const axios = require('axios');

// Test the Multi-Language Customer Support Generator

const BASE_URL = 'http://localhost:3000';

async function testAPI() {
  console.log('🧪 Testing Multi-Language Customer Support Generator API\n');

  try {
    // Test 1: Health Check
    console.log('1. Testing Health Check...');
    const healthResponse = await axios.get(`${BASE_URL}/health`);
    console.log('✅ Health Check:', healthResponse.data.status);
    console.log('');

    // Test 2: Get Supported Languages
    console.log('2. Getting Supported Languages...');
    const languagesResponse = await axios.get(`${BASE_URL}/api/languages`);
    console.log('✅ Supported Languages:', Object.keys(languagesResponse.data).join(', '));
    console.log('');

    // Test 3: English Query
    console.log('3. Testing English Support Query...');
    const englishQuery = {
      message: 'I forgot my password and need help resetting it',
      customerEmail: 'test@example.com',
      customerName: 'Test User'
    };
    const englishResponse = await axios.post(`${BASE_URL}/api/support/query`, englishQuery);
    console.log('✅ English Query Response:');
    console.log(`   Original: "${englishResponse.data.originalMessage}"`);
    console.log(`   Language: ${englishResponse.data.originalLanguage}`);
    console.log(`   Category: ${englishResponse.data.category}`);
    console.log(`   Priority: ${englishResponse.data.priority}`);
    console.log(`   Response: "${englishResponse.data.response.substring(0, 100)}..."`);
    console.log('');

    // Test 4: Spanish Query
    console.log('4. Testing Spanish Support Query...');
    const spanishQuery = {
      message: '¿Cómo puedo cancelar mi suscripción? Es urgente.',
      customerEmail: 'usuario@ejemplo.com',
      customerName: 'Usuario Prueba'
    };
    const spanishResponse = await axios.post(`${BASE_URL}/api/support/query`, spanishQuery);
    console.log('✅ Spanish Query Response:');
    console.log(`   Original: "${spanishResponse.data.originalMessage}"`);
    console.log(`   Language: ${spanishResponse.data.originalLanguage}`);
    console.log(`   Translated to English: "${spanishResponse.data.translatedMessage}"`);
    console.log(`   Category: ${spanishResponse.data.category}`);
    console.log(`   Priority: ${spanishResponse.data.priority}`);
    console.log(`   Response (Spanish): "${spanishResponse.data.translatedResponse.substring(0, 100)}..."`);
    console.log('');

    // Test 5: French Query
    console.log('5. Testing French Support Query...');
    const frenchQuery = {
      message: 'J\'ai un problème avec ma facture, pouvez-vous m\'aider?',
      customerEmail: 'utilisateur@exemple.fr',
      customerName: 'Utilisateur Test'
    };
    const frenchResponse = await axios.post(`${BASE_URL}/api/support/query`, frenchQuery);
    console.log('✅ French Query Response:');
    console.log(`   Original: "${frenchResponse.data.originalMessage}"`);
    console.log(`   Language: ${frenchResponse.data.originalLanguage}`);
    console.log(`   Translated to English: "${frenchResponse.data.translatedMessage}"`);
    console.log(`   Category: ${frenchResponse.data.category}`);
    console.log(`   Priority: ${frenchResponse.data.priority}`);
    console.log('');

    // Test 6: Get Analytics
    console.log('6. Getting Analytics...');
    const analyticsResponse = await axios.get(`${BASE_URL}/api/support/analytics`);
    console.log('✅ Analytics:');
    console.log(`   Total Tickets: ${analyticsResponse.data.totalTickets}`);
    console.log(`   Total Customers: ${analyticsResponse.data.totalCustomers}`);
    console.log(`   Language Distribution:`, analyticsResponse.data.languageDistribution);
    console.log(`   Category Distribution:`, analyticsResponse.data.categoryDistribution);
    console.log('');

    console.log('🎉 All tests completed successfully!');
    console.log('');
    console.log('🌐 You can now visit http://localhost:3000 to use the web interface');
    console.log('📚 API is ready to handle customer support queries in multiple languages');

  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

// Run tests
testAPI();
