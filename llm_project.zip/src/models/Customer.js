class Customer {
  constructor({
    email,
    name,
    preferredLanguage,
    timezone,
    tickets = [],
    createdAt,
    lastContact
  }) {
    this.email = email;
    this.name = name;
    this.preferredLanguage = preferredLanguage || 'en';
    this.timezone = timezone || 'UTC';
    this.tickets = tickets;
    this.createdAt = createdAt || new Date().toISOString();
    this.lastContact = lastContact;
  }

  addTicket(ticketId) {
    this.tickets.push(ticketId);
    this.lastContact = new Date().toISOString();
  }

  getTicketCount() {
    return this.tickets.length;
  }

  updatePreferredLanguage(language) {
    this.preferredLanguage = language;
  }

  toJSON() {
    return {
      email: this.email,
      name: this.name,
      preferredLanguage: this.preferredLanguage,
      timezone: this.timezone,
      ticketCount: this.getTicketCount(),
      createdAt: this.createdAt,
      lastContact: this.lastContact
    };
  }
}

module.exports = Customer;
