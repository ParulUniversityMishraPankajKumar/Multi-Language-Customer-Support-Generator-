class SupportTicket {
  constructor({
    id,
    customerEmail,
    customerName,
    originalMessage,
    originalLanguage,
    translatedMessage,
    response,
    translatedResponse,
    category,
    priority,
    status,
    timestamp,
    resolvedAt
  }) {
    this.id = id;
    this.customerEmail = customerEmail;
    this.customerName = customerName;
    this.originalMessage = originalMessage;
    this.originalLanguage = originalLanguage;
    this.translatedMessage = translatedMessage;
    this.response = response;
    this.translatedResponse = translatedResponse;
    this.category = category || 'general';
    this.priority = priority || 'medium';
    this.status = status || 'open';
    this.timestamp = timestamp;
    this.resolvedAt = resolvedAt;
  }

  markAsResolved() {
    this.status = 'resolved';
    this.resolvedAt = new Date().toISOString();
  }

  updatePriority(priority) {
    const validPriorities = ['low', 'medium', 'high', 'urgent'];
    if (validPriorities.includes(priority)) {
      this.priority = priority;
    }
  }

  addResponse(response, translatedResponse) {
    this.response = response;
    this.translatedResponse = translatedResponse;
  }

  toJSON() {
    return {
      id: this.id,
      customerEmail: this.customerEmail,
      customerName: this.customerName,
      originalMessage: this.originalMessage,
      originalLanguage: this.originalLanguage,
      translatedMessage: this.translatedMessage,
      response: this.response,
      translatedResponse: this.translatedResponse,
      category: this.category,
      priority: this.priority,
      status: this.status,
      timestamp: this.timestamp,
      resolvedAt: this.resolvedAt
    };
  }
}

module.exports = SupportTicket;
