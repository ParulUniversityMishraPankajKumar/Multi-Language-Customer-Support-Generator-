const SupportTicket = require('../models/SupportTicket');
const Customer = require('../models/Customer');
const logger = require('../utils/logger');

class SupportService {
  constructor({ translationService, languageDetector, responseGenerator }) {
    this.translationService = translationService;
    this.languageDetector = languageDetector;
    this.responseGenerator = responseGenerator;
    this.tickets = new Map(); // In-memory storage (use database in production)
    this.customers = new Map();
    this.analytics = {
      totalTickets: 0,
      languageDistribution: {},
      categoryDistribution: {},
      resolutionTimes: []
    };
  }

  async processQuery(queryData) {
    try {
      const { id, message, customerEmail, customerName, timestamp } = queryData;

      // Detect language of the incoming message
      const detectedLanguage = await this.languageDetector.detectLanguage(message);
      logger.info('Language detected:', { language: detectedLanguage });

      // Translate to English for processing (if not already English)
      let translatedMessage = message;
      if (detectedLanguage !== 'en') {
        translatedMessage = await this.translationService.translate(
          message, 
          detectedLanguage, 
          'en'
        );
      }

      // Categorize the query
      const category = this.categorizeQuery(translatedMessage);
      
      // Determine priority
      const priority = this.determinePriority(translatedMessage, category);

      // Generate response
      const englishResponse = await this.responseGenerator.generateResponse(
        translatedMessage, 
        category,
        priority
      );

      // Translate response back to original language
      let finalResponse = englishResponse;
      if (detectedLanguage !== 'en') {
        finalResponse = await this.translationService.translate(
          englishResponse,
          'en',
          detectedLanguage
        );
      }

      // Create support ticket
      const ticket = new SupportTicket({
        id,
        customerEmail,
        customerName,
        originalMessage: message,
        originalLanguage: detectedLanguage,
        translatedMessage,
        response: englishResponse,
        translatedResponse: finalResponse,
        category,
        priority,
        status: 'resolved', // Auto-resolved for AI responses
        timestamp,
        resolvedAt: new Date().toISOString()
      });

      // Store ticket
      this.tickets.set(id, ticket);

      // Update customer record
      this.updateCustomerRecord(customerEmail, customerName, detectedLanguage, id);

      // Update analytics
      this.updateAnalytics(ticket);

      logger.info('Support ticket created:', { ticketId: id, category, priority });

      return ticket.toJSON();
    } catch (error) {
      logger.error('Error processing query:', error);
      throw error;
    }
  }

  async getTicket(ticketId) {
    const ticket = this.tickets.get(ticketId);
    return ticket ? ticket.toJSON() : null;
  }

  updateCustomerRecord(email, name, language, ticketId) {
    let customer = this.customers.get(email);
    
    if (!customer) {
      customer = new Customer({
        email,
        name,
        preferredLanguage: language
      });
      this.customers.set(email, customer);
    }
    
    customer.addTicket(ticketId);
  }

  categorizeQuery(message) {
    const categories = {
      'password': ['password', 'login', 'sign in', 'access', 'account'],
      'billing': ['bill', 'payment', 'charge', 'invoice', 'subscription'],
      'technical': ['error', 'bug', 'broken', 'not working', 'issue'],
      'product': ['feature', 'how to', 'tutorial', 'guide', 'documentation'],
      'cancellation': ['cancel', 'refund', 'unsubscribe', 'terminate'],
      'general': []
    };

    const lowerMessage = message.toLowerCase();
    
    for (const [category, keywords] of Object.entries(categories)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        return category;
      }
    }
    
    return 'general';
  }

  determinePriority(message, category) {
    const urgentKeywords = ['urgent', 'emergency', 'critical', 'broken', 'down'];
    const highKeywords = ['important', 'asap', 'quickly', 'soon'];
    
    const lowerMessage = message.toLowerCase();
    
    if (urgentKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return 'urgent';
    }
    
    if (highKeywords.some(keyword => lowerMessage.includes(keyword)) || 
        ['billing', 'technical'].includes(category)) {
      return 'high';
    }
    
    return 'medium';
  }

  updateAnalytics(ticket) {
    this.analytics.totalTickets++;
    
    // Language distribution
    const lang = ticket.originalLanguage;
    this.analytics.languageDistribution[lang] = 
      (this.analytics.languageDistribution[lang] || 0) + 1;
    
    // Category distribution
    this.analytics.categoryDistribution[ticket.category] = 
      (this.analytics.categoryDistribution[ticket.category] || 0) + 1;
    
    // Resolution time (immediate for AI responses)
    this.analytics.resolutionTimes.push(0);
  }

  async getAnalytics() {
    const avgResolutionTime = this.analytics.resolutionTimes.length > 0 
      ? this.analytics.resolutionTimes.reduce((a, b) => a + b, 0) / this.analytics.resolutionTimes.length
      : 0;

    return {
      totalTickets: this.analytics.totalTickets,
      totalCustomers: this.customers.size,
      languageDistribution: this.analytics.languageDistribution,
      categoryDistribution: this.analytics.categoryDistribution,
      averageResolutionTime: avgResolutionTime,
      topLanguages: this.getTopLanguages(),
      topCategories: this.getTopCategories()
    };
  }

  getTopLanguages() {
    return Object.entries(this.analytics.languageDistribution)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([lang, count]) => ({ language: lang, count }));
  }

  getTopCategories() {
    return Object.entries(this.analytics.categoryDistribution)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([category, count]) => ({ category, count }));
  }
}

module.exports = SupportService;
