const logger = require('../utils/logger');

class LanguageDetector {
  constructor() {
    // Language patterns and common words for detection
    this.languagePatterns = {
      'en': {
        common: ['the', 'and', 'you', 'that', 'was', 'for', 'are', 'with', 'his', 'they'],
        patterns: [/\b(the|and|you|that|was|for|are|with|his|they)\b/gi]
      },
      'es': {
        common: ['que', 'de', 'no', 'la', 'el', 'en', 'un', 'es', 'se', 'te'],
        patterns: [/\b(que|de|no|la|el|en|un|es|se|te)\b/gi, /ñ/g, /¿|¡/g]
      },
      'fr': {
        common: ['le', 'de', 'et', 'un', 'il', 'être', 'et', 'en', 'avoir', 'que'],
        patterns: [/\b(le|de|et|un|il|être|et|en|avoir|que)\b/gi, /[àâäéèêëïîôöùûü]/g]
      },
      'de': {
        common: ['der', 'die', 'und', 'in', 'den', 'von', 'zu', 'das', 'mit', 'sich'],
        patterns: [/\b(der|die|und|in|den|von|zu|das|mit|sich)\b/gi, /[äöüß]/g]
      },
      'it': {
        common: ['di', 'che', 'il', 'la', 'un', 'per', 'con', 'non', 'una', 'su'],
        patterns: [/\b(di|che|il|la|un|per|con|non|una|su)\b/gi]
      },
      'pt': {
        common: ['de', 'que', 'não', 'um', 'para', 'com', 'uma', 'em', 'mais', 'do'],
        patterns: [/\b(de|que|não|um|para|com|uma|em|mais|do)\b/gi, /[ãâàáêéíóôõú]/g]
      },
      'zh': {
        common: ['的', '了', '在', '是', '我', '有', '和', '就', '不', '人'],
        patterns: [/[\u4e00-\u9fff]/g]
      },
      'ja': {
        common: ['の', 'に', 'は', 'を', 'た', 'が', 'で', 'て', 'と', 'し'],
        patterns: [/[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]/g]
      },
      'ko': {
        common: ['이', '그', '저', '것', '수', '있', '하', '되', '같', '또'],
        patterns: [/[\uac00-\ud7af]/g]
      },
      'ar': {
        common: ['في', 'من', 'إلى', 'على', 'أن', 'هذا', 'هذه', 'التي', 'الذي', 'كان'],
        patterns: [/[\u0600-\u06ff]/g]
      },
      'ru': {
        common: ['в', 'и', 'не', 'на', 'я', 'быть', 'он', 'с', 'что', 'а'],
        patterns: [/[\u0400-\u04ff]/g]
      },
      'hi': {
        common: ['के', 'में', 'की', 'है', 'को', 'से', 'का', 'एक', 'पर', 'यह'],
        patterns: [/[\u0900-\u097f]/g]
      }
    };

    this.supportedLanguages = {
      'en': 'English',
      'es': 'Spanish', 
      'fr': 'French',
      'de': 'German',
      'it': 'Italian',
      'pt': 'Portuguese',
      'zh': 'Chinese',
      'ja': 'Japanese',
      'ko': 'Korean',
      'ar': 'Arabic',
      'ru': 'Russian',
      'hi': 'Hindi'
    };
  }

  async detectLanguage(text) {
    try {
      if (!text || text.trim().length === 0) {
        return 'en'; // Default to English for empty text
      }

      const cleanText = text.toLowerCase().trim();
      const scores = {};

      // Initialize scores
      Object.keys(this.languagePatterns).forEach(lang => {
        scores[lang] = 0;
      });

      // Score based on character patterns
      for (const [lang, data] of Object.entries(this.languagePatterns)) {
        // Check for specific character patterns
        data.patterns.forEach(pattern => {
          const matches = cleanText.match(pattern);
          if (matches) {
            scores[lang] += matches.length;
          }
        });

        // Check for common words
        data.common.forEach(word => {
          const regex = new RegExp('\\b' + word + '\\b', 'gi');
          const matches = cleanText.match(regex);
          if (matches) {
            scores[lang] += matches.length * 2; // Weight common words more
          }
        });
      }

      // Additional heuristics
      this.applyAdditionalHeuristics(cleanText, scores);

      // Find language with highest score
      let detectedLang = 'en';
      let maxScore = 0;

      for (const [lang, score] of Object.entries(scores)) {
        if (score > maxScore) {
          maxScore = score;
          detectedLang = lang;
        }
      }

      // If no clear detection, use additional fallback logic
      if (maxScore === 0) {
        detectedLang = this.fallbackDetection(cleanText);
      }

      logger.info('Language detection completed:', { 
        detected: detectedLang, 
        score: maxScore,
        textLength: text.length 
      });

      return detectedLang;
    } catch (error) {
      logger.error('Language detection error:', error);
      return 'en'; // Default to English on error
    }
  }

  applyAdditionalHeuristics(text, scores) {
    // Check for specific language indicators
    
    // Spanish indicators
    if (/[ñü]/.test(text) || /\b(señor|señora|gracias|hola|adiós)\b/.test(text)) {
      scores.es += 5;
    }

    // French indicators
    if (/[àâäéèêëïîôöùûü]/.test(text) || /\b(bonjour|merci|au revoir|oui|non)\b/.test(text)) {
      scores.fr += 5;
    }

    // German indicators
    if (/[äöüß]/.test(text) || /\b(guten|danke|bitte|ja|nein)\b/.test(text)) {
      scores.de += 5;
    }

    // Portuguese indicators
    if (/[ãâàáêéíóôõú]/.test(text) || /\b(obrigado|olá|tchau|sim|não)\b/.test(text)) {
      scores.pt += 5;
    }

    // Chinese indicators
    if (/[\u4e00-\u9fff]/.test(text)) {
      scores.zh += 10;
    }

    // Japanese indicators
    if (/[\u3040-\u309f\u30a0-\u30ff]/.test(text)) {
      scores.ja += 10;
    }

    // Korean indicators
    if (/[\uac00-\ud7af]/.test(text)) {
      scores.ko += 10;
    }

    // Arabic indicators
    if (/[\u0600-\u06ff]/.test(text)) {
      scores.ar += 10;
    }

    // Russian indicators
    if (/[\u0400-\u04ff]/.test(text)) {
      scores.ru += 10;
    }

    // Hindi indicators
    if (/[\u0900-\u097f]/.test(text)) {
      scores.hi += 10;
    }
  }

  fallbackDetection(text) {
    // Simple character-based fallback
    if (/[\u4e00-\u9fff]/.test(text)) return 'zh';
    if (/[\u3040-\u309f\u30a0-\u30ff]/.test(text)) return 'ja';
    if (/[\uac00-\ud7af]/.test(text)) return 'ko';
    if (/[\u0600-\u06ff]/.test(text)) return 'ar';
    if (/[\u0400-\u04ff]/.test(text)) return 'ru';
    if (/[\u0900-\u097f]/.test(text)) return 'hi';
    if (/[àâäéèêëïîôöùûü]/.test(text)) return 'fr';
    if (/[äöüß]/.test(text)) return 'de';
    if (/[ñü]/.test(text)) return 'es';
    if (/[ãâàáêéíóôõú]/.test(text)) return 'pt';
    
    return 'en'; // Default to English
  }

  getSupportedLanguages() {
    return this.supportedLanguages;
  }

  isLanguageSupported(languageCode) {
    return languageCode in this.supportedLanguages;
  }

  getLanguageName(languageCode) {
    return this.supportedLanguages[languageCode] || 'Unknown';
  }

  getConfidence(text, detectedLanguage) {
    // Calculate confidence score for the detection
    const scores = {};
    Object.keys(this.languagePatterns).forEach(lang => {
      scores[lang] = 0;
    });

    const cleanText = text.toLowerCase();
    const data = this.languagePatterns[detectedLanguage];
    
    if (!data) return 0;

    let totalMatches = 0;
    data.patterns.forEach(pattern => {
      const matches = cleanText.match(pattern);
      if (matches) {
        totalMatches += matches.length;
      }
    });

    // Return confidence as percentage
    return Math.min(100, (totalMatches / text.length) * 100);
  }
}

module.exports = LanguageDetector;
