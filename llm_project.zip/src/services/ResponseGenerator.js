const OpenAI = require('openai');
const logger = require('../utils/logger');

class ResponseGenerator {
  constructor() {
    this.openai = process.env.OPENAI_API_KEY ? new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    }) : null;

    // Predefined response templates for common scenarios
    this.responseTemplates = {
      password: {
        medium: "I understand you're having trouble with your password. To reset your password, please follow these steps:\n\n1. Go to the login page\n2. Click on 'Forgot Password'\n3. Enter your email address\n4. Check your email for reset instructions\n5. Follow the link in the email to create a new password\n\nIf you continue to have issues, please contact our support team with your account email address.",
        high: "I see this is urgent. For immediate password reset assistance:\n\n1. Use the 'Forgot Password' link on the login page\n2. If you don't receive the email within 5 minutes, check your spam folder\n3. For immediate help, contact our 24/7 support line\n\nWe're here to help you regain access quickly.",
        urgent: "This appears to be critical. For immediate password assistance:\n\n🚨 URGENT SUPPORT NEEDED\n1. Try the automated password reset first\n2. If unsuccessful, contact emergency support immediately\n3. We'll prioritize your request for immediate resolution\n\nContact: emergency-support@company.com"
      },
      billing: {
        medium: "Thank you for contacting us about your billing inquiry. I'm here to help clarify any questions about your account.\n\nTo better assist you, please provide:\n- Your account email\n- The specific billing question or concern\n- Invoice number (if applicable)\n\nOur billing team will review your account and respond within 24 hours with detailed information.",
        high: "I understand billing issues can be concerning. Let me help you resolve this quickly.\n\nFor immediate billing assistance:\n1. Check your account dashboard for recent transactions\n2. Review your latest invoice\n3. Contact our billing specialist directly\n\nWe prioritize billing inquiries and will resolve this within 4 hours.",
        urgent: "I see this billing issue requires immediate attention.\n\n🚨 URGENT BILLING SUPPORT\n1. We're escalating this to our senior billing team\n2. You'll receive a response within 1 hour\n3. Emergency billing contact: billing-urgent@company.com\n\nWe understand the urgency and will resolve this immediately."
      },
      technical: {
        medium: "Thank you for reporting this technical issue. I'm here to help you resolve it.\n\nTo troubleshoot effectively, please try:\n1. Refresh your browser/restart the app\n2. Clear your browser cache\n3. Check your internet connection\n4. Try using a different browser\n\nIf the issue persists, please provide:\n- Error messages you're seeing\n- Your device/browser information\n- Steps that led to the issue",
        high: "I understand this technical issue is impacting your work. Let's resolve this quickly.\n\nImmediate steps:\n1. Document any error messages\n2. Try the basic troubleshooting steps\n3. If unsuccessful, we'll escalate to our technical team\n\nOur technical specialists will investigate and respond within 2 hours.",
        urgent: "This technical issue requires immediate attention.\n\n🚨 CRITICAL TECHNICAL SUPPORT\n1. We're assigning a senior technician immediately\n2. Emergency technical line: tech-emergency@company.com\n3. Expected resolution: Within 30 minutes\n\nWe understand this is critical to your operations."
      },
      product: {
        medium: "I'm happy to help you learn more about our product features.\n\nFor the information you need:\n1. Check our comprehensive documentation\n2. Watch our tutorial videos\n3. Explore our FAQ section\n\nIf you need specific guidance, please let me know:\n- What feature you're interested in\n- Your current use case\n- Any specific questions\n\nI'll provide detailed guidance tailored to your needs.",
        high: "I understand you need detailed product information quickly.\n\nFor immediate assistance:\n1. I'll provide direct links to relevant resources\n2. Schedule a product demo if needed\n3. Connect you with our product specialist\n\nWhat specific aspect of our product would you like to explore?",
        urgent: "I see you need urgent product information.\n\n🚨 PRIORITY PRODUCT SUPPORT\n1. Immediate consultation with product expert\n2. Custom demo scheduled within the hour\n3. Direct line: product-urgent@company.com\n\nWe'll ensure you have everything needed immediately."
      },
      cancellation: {
        medium: "I understand you're considering canceling your subscription. Before we proceed, I'd like to help address any concerns you might have.\n\nOptions available:\n1. Pause your subscription temporarily\n2. Downgrade to a different plan\n3. Get additional support to resolve issues\n4. Process cancellation if that's your preference\n\nWhat specific concerns led to this decision? We value your feedback.",
        high: "I see you want to cancel your subscription soon. Let me help you with the best solution.\n\nImmediate options:\n1. Instant plan modification\n2. Retention specialist consultation\n3. Express cancellation process\n\nWould you be open to discussing alternatives that might better meet your needs?",
        urgent: "I understand this cancellation request is urgent.\n\n🚨 URGENT CANCELLATION SUPPORT\n1. Immediate processing available\n2. Senior retention specialist assigned\n3. Emergency contact: retention-urgent@company.com\n\nWe'll process this immediately while exploring any last-minute solutions."
      },
      general: {
        medium: "Thank you for reaching out! I'm here to help with your inquiry.\n\nTo provide the best assistance, could you please provide more details about:\n- What you're trying to accomplish\n- Any specific questions you have\n- How I can best help you today\n\nI'm committed to resolving your inquiry promptly and thoroughly.",
        high: "Thank you for contacting us. I understand this is important to you.\n\nFor quick resolution:\n1. I'll prioritize your request\n2. Connect you with the right specialist if needed\n3. Ensure you get comprehensive assistance\n\nPlease share more details so I can help you effectively.",
        urgent: "Thank you for reaching out with your urgent request.\n\n🚨 PRIORITY GENERAL SUPPORT\n1. Immediate escalation to senior support\n2. Dedicated agent assignment\n3. Emergency line: general-urgent@company.com\n\nWe're committed to resolving this immediately."
      }
    };
  }

  async generateResponse(message, category = 'general', priority = 'medium') {
    try {
      // Use AI if available, otherwise use templates
      if (this.openai) {
        return await this.generateAIResponse(message, category, priority);
      } else {
        return this.generateTemplateResponse(category, priority);
      }
    } catch (error) {
      logger.error('Error generating response:', error);
      return this.generateFallbackResponse(category, priority);
    }
  }

  async generateAIResponse(message, category, priority) {
    try {
      const systemPrompt = this.buildSystemPrompt(category, priority);
      
      const response = await this.openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user", 
            content: message
          }
        ],
        max_tokens: 500,
        temperature: 0.7
      });

      const aiResponse = response.choices[0].message.content;
      logger.info('AI response generated successfully');
      
      return aiResponse;
    } catch (error) {
      logger.error('OpenAI API error:', error);
      throw error;
    }
  }

  buildSystemPrompt(category, priority) {
    const urgencyMap = {
      'low': 'standard',
      'medium': 'prompt', 
      'high': 'urgent',
      'urgent': 'critical'
    };

    return `You are a helpful customer support representative. 

Context:
- Customer inquiry category: ${category}
- Priority level: ${priority} (${urgencyMap[priority]} response needed)

Instructions:
- Provide helpful, professional, and empathetic responses
- Address the customer's concern directly
- Offer clear next steps or solutions
- Maintain a friendly but professional tone
- For urgent matters, emphasize immediate assistance
- Include relevant contact information when appropriate
- Keep responses concise but comprehensive
- Always aim to resolve the customer's issue

Remember: The customer's satisfaction is our top priority.`;
  }

  generateTemplateResponse(category, priority) {
    const templates = this.responseTemplates[category] || this.responseTemplates.general;
    const response = templates[priority] || templates.medium;
    
    logger.info('Template response generated:', { category, priority });
    return response;
  }

  generateFallbackResponse(category, priority) {
    const urgencyText = priority === 'urgent' ? 'urgent ' : priority === 'high' ? 'priority ' : '';
    
    return `Thank you for contacting our support team. I understand you have ${urgencyText}a ${category} inquiry.

While I process your request, here's what you can expect:

1. Your inquiry has been received and logged
2. Our team will review your case based on its ${priority} priority
3. You'll receive a detailed response soon
4. For immediate assistance, you can also contact our support team directly

We appreciate your patience and are committed to resolving your inquiry promptly.

Best regards,
Customer Support Team`;
  }

  async generateMultipleResponses(message, category, priority, count = 3) {
    try {
      const responses = [];
      for (let i = 0; i < count; i++) {
        const response = await this.generateResponse(message, category, priority);
        responses.push(response);
      }
      return responses;
    } catch (error) {
      logger.error('Error generating multiple responses:', error);
      return [this.generateFallbackResponse(category, priority)];
    }
  }

  getSupportedCategories() {
    return Object.keys(this.responseTemplates);
  }

  getSupportedPriorities() {
    return ['low', 'medium', 'high', 'urgent'];
  }
}

module.exports = ResponseGenerator;
