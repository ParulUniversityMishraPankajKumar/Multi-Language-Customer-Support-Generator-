const translate = require('translate-google');
const logger = require('../utils/logger');

class TranslationService {
  constructor() {
    this.cache = new Map(); // Simple translation cache
    this.supportedLanguages = {
      'en': 'English',
      'es': 'Spanish',
      'fr': 'French',
      'de': 'German',
      'it': 'Italian',
      'pt': 'Portuguese',
      'zh': 'Chinese',
      'ja': 'Japanese',
      'ko': 'Korean',
      'ar': 'Arabic',
      'ru': 'Russian',
      'hi': 'Hindi',
      'nl': 'Dutch',
      'sv': 'Swedish',
      'no': 'Norwegian'
    };
  }

  async translate(text, fromLang, toLang) {
    try {
      // Return original text if same language
      if (fromLang === toLang) {
        return text;
      }

      // Check cache first
      const cacheKey = `${text}_${fromLang}_${toLang}`;
      if (this.cache.has(cacheKey)) {
        logger.debug('Translation cache hit');
        return this.cache.get(cacheKey);
      }

      // Perform translation
      logger.info('Translating text:', { 
        from: fromLang, 
        to: toLang, 
        textLength: text.length 
      });

      const result = await translate(text, { from: fromLang, to: toLang });
      
      // Cache the result
      this.cache.set(cacheKey, result);
      
      // Limit cache size
      if (this.cache.size > 1000) {
        const firstKey = this.cache.keys().next().value;
        this.cache.delete(firstKey);
      }

      return result;
    } catch (error) {
      logger.error('Translation error:', error);
      
      // Fallback: return original text if translation fails
      logger.warn('Translation failed, returning original text');
      return text;
    }
  }

  async translateBatch(texts, fromLang, toLang) {
    try {
      const translations = await Promise.all(
        texts.map(text => this.translate(text, fromLang, toLang))
      );
      return translations;
    } catch (error) {
      logger.error('Batch translation error:', error);
      return texts; // Return original texts on error
    }
  }

  getSupportedLanguages() {
    return this.supportedLanguages;
  }

  isLanguageSupported(languageCode) {
    return languageCode in this.supportedLanguages;
  }

  getLanguageName(languageCode) {
    return this.supportedLanguages[languageCode] || 'Unknown';
  }

  clearCache() {
    this.cache.clear();
    logger.info('Translation cache cleared');
  }

  getCacheStats() {
    return {
      size: this.cache.size,
      maxSize: 1000
    };
  }
}

module.exports = TranslationService;
