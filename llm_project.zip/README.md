# Multi-Language Customer Support Generator

An AI-powered customer support system that can handle queries in multiple languages, automatically translate them, and generate appropriate responses.

## Features

- **Multi-language Detection**: Automatically detects the language of incoming customer queries
- **Translation Service**: Translates queries to a base language for processing
- **AI Response Generation**: Uses AI to generate contextually appropriate responses
- **Response Translation**: Translates responses back to the customer's language
- **Support Ticket Management**: Creates and manages support tickets
- **Analytics**: Tracks support metrics and language usage

## Supported Languages

- English (en)
- Spanish (es)
- French (fr)
- German (de)
- Italian (it)
- Portuguese (pt)
- Chinese (zh)
- Japanese (ja)
- Korean (ko)
- Arabic (ar)

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file with your API keys:
   ```
   OPENAI_API_KEY=your_openai_api_key
   PORT=3000
   ```
4. Start the application:
   ```bash
   npm start
   ```

## API Endpoints

- `POST /api/support/query` - Submit a customer support query
- `GET /api/support/ticket/:id` - Get ticket details
- `GET /api/support/analytics` - Get support analytics
- `GET /api/languages` - Get supported languages

## Usage

### Submit a Support Query

```javascript
const response = await fetch('/api/support/query', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: "¿Cómo puedo restablecer mi contraseña?",
    customerEmail: "customer@example.com"
  })
});
```

## Architecture

- **Language Detection**: Uses language detection algorithms to identify input language
- **Translation**: Google Translate API for language translation
- **AI Processing**: OpenAI GPT for response generation
- **Response Management**: Structured response system with templates

## Testing

```bash
npm test
```

## Development

```bash
npm run dev
```
